const API="https://genshin-db-api.vercel.app/api/v5";
const STATS={"PV%":"percent","ATQ%":"percent","DEF%":"percent","Maîtrise élémentaire":"flat","Recharge d'énergie":"percent","TC":"percent","DC":"percent","PV flat":"flat","ATQ flat":"flat","DEF flat":"flat","Bonus Pyro":"percent","Bonus Hydro":"percent","Bonus Électro":"percent","Bonus Cryo":"percent","Bonus Anémo":"percent","Bonus Géo":"percent","Bonus Dendro":"percent","Bonus physique":"percent","Soin":"percent"};
const ROLLS={"TC":[2.7,3.1,3.5,3.9],"DC":[5.4,6.2,7,7.8],"ATQ%":[4.1,4.7,5.3,5.8],"Recharge d'énergie":[4.5,5.2,5.8,6.5],"Maîtrise élémentaire":[16,19,21,23],"DEF%":[5.1,5.8,6.6,7.3],"PV%":[4.1,4.7,5.3,5.8],"ATQ flat":[14,16,18,19],"DEF flat":[16,19,21,23],"PV flat":[209,239,269,299]};
const MAIN={Fleur:["PV flat"],Plume:["ATQ flat"],Sablier:["PV%","ATQ%","DEF%","Maîtrise élémentaire","Recharge d'énergie"],Coupe:["PV%","ATQ%","DEF%","Maîtrise élémentaire","Bonus Pyro","Bonus Hydro","Bonus Électro","Bonus Cryo","Bonus Anémo","Bonus Géo","Bonus Dendro","Bonus physique"],Couronne:["PV%","ATQ%","DEF%","Maîtrise élémentaire","TC","DC","Soin"]};
const MAIN_VALUES={"PV flat":4780,"ATQ flat":311,"PV%":46.6,"ATQ%":46.6,"DEF%":58.3,"Maîtrise élémentaire":187,"Recharge d'énergie":51.8,"Bonus Pyro":46.6,"Bonus Hydro":46.6,"Bonus Électro":46.6,"Bonus Cryo":46.6,"Bonus Anémo":46.6,"Bonus Géo":46.6,"Bonus Dendro":46.6,"Bonus physique":58.3,"TC":31.1,"DC":62.2,"Soin":35.9};
const SLOTS=Object.keys(MAIN);
const $=x=>document.getElementById(x),esc=s=>String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
let db=[],current=null,builds=JSON.parse(localStorage.getItem("teyvat_builds_v5")||"[]"),artifactSets=[],artifactSetMap=new Map();
function opts(arr,sel=""){return arr.map(x=>`<option value="${esc(x)}" ${String(x)===String(sel)?"selected":""}>${esc(x)}</option>`).join("")}
function statOpts(sel=""){return opts(Object.keys(STATS),sel)}
function fmt(n,u=""){return `${Math.round((Number(n)||0)*10)/10}${u}`}
function save(){localStorage.setItem("teyvat_builds_v5",JSON.stringify(builds))}
const GDB_CDN="https://cdn.jsdelivr.net/gh/theBowja/genshin-db-dist@main";
const gdbLoaded=new Map();
function gdbFolderFn(folder){return String(folder).replace(/-([a-z])/g,(_,c)=>c.toUpperCase()).replace(/^./,c=>c.toLowerCase())}
function loadScript(src){return new Promise((resolve,reject)=>{const s=document.createElement("script");s.src=src;s.async=true;s.onload=resolve;s.onerror=()=>reject(new Error("Impossible de charger "+src));document.head.appendChild(s)})}
async function ensureGDB(folder){
  // genshindb-nodata.js définit déjà les fonctions de recherche. Leur présence
  // ne signifie PAS que le fichier de données du dossier est chargé.
  if(gdbLoaded.has(folder))return gdbLoaded.get(folder);
  const promise=(async()=>{
    if(!window.GenshinDb)await loadScript(`${GDB_CDN}/genshindb-nodata.js`);
    await loadScript(`${GDB_CDN}/data/scripts/english-${folder}.js`);
    return window.GenshinDb;
  })().catch(err=>{gdbLoaded.delete(folder);throw err});
  gdbLoaded.set(folder,promise);
  return promise;
}
function gdbNames(folder){const f=gdbFolderFn(folder);try{const g=window.GenshinDb?.[f];const out=g?.("names",{matchCategories:true,matchNames:true,matchAltNames:true,matchAliases:true});if(Array.isArray(out))return out.map(x=>typeof x==="string"?x:x?.name).filter(Boolean);if(out?.result&&Array.isArray(out.result))return out.result.map(x=>typeof x==="string"?x:x?.name).filter(Boolean)}catch(e){}return []}
function gdbSearch(folder,q){const f=gdbFolderFn(folder);const fn=window.GenshinDb?.[f];if(!fn)return [];const opts={matchNames:true,matchAltNames:true,matchAliases:true,matchCategories:false};const r=fn(q||"names",opts);if(!r)return [];if(Array.isArray(r))return r;return [r]}
function artifactSetRecords(){
  const f=gdbFolderFn("artifacts");
  const fn=window.GenshinDb?.[f];
  if(!fn)return [];
  let rawList=[];
  try{
    const r=fn("names",{matchCategories:true,verboseCategories:true,queryLanguages:["English"],resultLanguage:"English"});
    rawList=Array.isArray(r)?r:(r?.result&&Array.isArray(r.result)?r.result:[]);
  }catch(e){rawList=[]}
  const out=rawList.filter(x=>x&&typeof x==="object"&&x.name).map(x=>normalizeArtifactRecord(x,String(x.name)));
  const seen=new Set();
  return out.filter(x=>{const k=x.englishName.toLowerCase();if(seen.has(k))return false;seen.add(k);return true}).sort((a,b)=>a.name.localeCompare(b.name,"en"));
}
function artifactImageValue(raw,key){
  const cap=key.charAt(0).toUpperCase()+key.slice(1);
  const piece=raw?.pieces?.[key]||raw?.artifacts?.[key]||raw?.[key];
  const candidates=[
    piece?.img,piece?.image,piece?.icon,piece?.nameicon,piece?.nameIcon,
    raw?.images?.[key],raw?.images?.[`mihoyo_${key}`],
    raw?.[`${key}Image`],raw?.[`${key}image`],raw?.[cap],raw?.[cap+'Image'],
    piece?.images?.[key],piece?.images?.[0]
  ];
  for(const v of candidates){
    if(typeof v==='string'&&/^https?:\/\//.test(v))return v;
    if(v&&typeof v==='object')for(const z of Object.values(v))if(typeof z==='string'&&/^https?:\/\//.test(z))return z;
  }
  const fn=raw?.images?.[`filename_${key}`];
  if(typeof fn==='string'&&fn)return `https://res.cloudinary.com/genshin/image/upload/sprites/${fn}.png`;
  const id=raw?.id||raw?.itemId||raw?.key;
  const suffix={flower:4,plume:2,sands:5,goblet:1,circlet:3}[key]||4;
  if(id && /^\d+$/.test(String(id))){
    return `https://upload-os-bbs.hoyolab.com/game_record/genshin/equip/UI_RelicIcon_${id}_${suffix}.png`;
  }
  return '';
}
function normalizeArtifactRecord(raw,englishName=''){
  const images={};
  for(const k of ['flower','plume','sands','goblet','circlet'])images[k]=artifactImageValue(raw,k);
  return {
    name:String(raw?.name||englishName),
    englishName:String(englishName||raw?.name||''),
    effect2Pc:String(raw?.effect2Pc||raw?.['2pc']||raw?.effect2pc||''),
    effect4Pc:String(raw?.effect4Pc||raw?.['4pc']||raw?.effect4pc||''),
    images,raw
  };
}
async function loadArtifactSets(){
  try{
    await ensureGDB("artifacts");
    const english=artifactSetRecords();
    const map=new Map();
    for(const r of english)map.set(r.englishName.toLowerCase(),r);

    // Source principale : catégories complètes de Genshin-DB en français.
    // verboseCategories est nécessaire : sans lui, "names" ne renvoie que les noms.
    try{
      const url=`${API}/artifacts?query=names&matchCategories=true&verboseCategories=true&queryLanguages=French&resultLanguage=French`;
      const resp=await fetch(url,{cache:"no-store"});
      if(resp.ok){
        const json=await resp.json();
        const vals=Array.isArray(json)?json:(Array.isArray(json?.result)?json.result:Array.isArray(json?.data)?json.data:Array.isArray(json?.results)?json.results:[]);
        for(const item of vals){
          if(!item||typeof item!=="object"||!item.name)continue;
          const englishName=String(item.englishName||item.name_en||item.nameEnglish||'');
          let base=englishName?map.get(englishName.toLowerCase()):null;
          if(!base&&item.id)base=[...map.values()].find(x=>String(x.raw?.id)===String(item.id))||null;
          if(!base)continue;
          base.name=String(item.name);
          base.rawFrench=item;
          base.effect2Pc=String(item.effect2Pc||item["2pc"]||item.effect2pc||base.effect2Pc||"");
          base.effect4Pc=String(item.effect4Pc||item["4pc"]||item.effect4pc||base.effect4Pc||"");
          for(const k of ['flower','plume','sands','goblet','circlet']){
            const im=artifactImageValue(item,k);
            if(im)base.images[k]=im;
          }
        }
      }
    }catch(frErr){console.warn('API française des artefacts indisponible, fallback anglais',frErr)}

    artifactSets=[...map.values()].sort((a,b)=>a.name.localeCompare(b.name,'fr'));
    artifactSetMap=new Map();
    artifactSets.forEach(x=>{
      artifactSetMap.set(x.name.toLowerCase(),x);
      artifactSetMap.set(x.englishName.toLowerCase(),x);
    });
    if(current){await ensureActiveArtifactSetDetails();renderArtifacts();renderSetConditions();updateTotals();}
  }catch(e){
    console.warn("Chargement des sets d'artefacts impossible",e);
    artifactSets=[];artifactSetMap=new Map();
  }
}
async function fetchArtifactSetDetail(setName){
  const rec=artifactSetMap.get(String(setName||'').toLowerCase());
  if(!rec) return null;
  if(rec._detailsLoaded) return rec;
  const queries=[rec.name,rec.englishName].filter(Boolean);
  for(const q of queries){
    try{
      const url=`${API}/artifacts?query=${encodeURIComponent(q)}&matchNames=true&matchAltNames=true&queryLanguages=French,English&resultLanguage=English`;
      const resp=await fetch(url,{cache:'force-cache'});
      if(!resp.ok) continue;
      const json=await resp.json();
      const vals=Array.isArray(json)?json:(Array.isArray(json?.result)?json.result:Array.isArray(json?.data)?json.data:Array.isArray(json?.results)?json.results:[]);
      const item=vals.find(x=>x&&typeof x==='object') || (json&&typeof json==='object'&&!Array.isArray(json)&&json.result&&typeof json.result==='object'?json.result:null);
      if(!item) continue;
      rec.raw=item;
      rec.id=item.id||item.key||item._id||rec.id||'';
      rec.effect2Pc=String(item.effect2Pc||item.effect2pc||item['2pc']||item.bonus?.['2pc']||item.bonus?.['2Pc']||item.bonus?.twoPc||'');
      rec.effect4Pc=String(item.effect4Pc||item.effect4pc||item['4pc']||item.bonus?.['4pc']||item.bonus?.['4Pc']||item.bonus?.fourPc||'');
      rec.images=rec.images||{};
      const pieces=item.pieces||item.artifacts||{};
      for(const k of ['flower','plume','sands','goblet','circlet']){
        const piece=pieces?.[k]||item?.[k];
        const im=piece?.img||piece?.image||piece?.icon||piece?.nameicon||piece?.nameIcon;
        if(typeof im==='string'&&/^https?:\/\//.test(im)) rec.images[k]=im;
      }
      rec._detailsLoaded=true;
      return rec;
    }catch(e){ console.warn('Détail set impossible',q,e); }
  }
  return rec;
}
async function ensureActiveArtifactSetDetails(){
  const names=[...new Set(Object.values(current?.artifacts||{}).map(a=>a?.set).filter(Boolean))];
  await Promise.all(names.map(fetchArtifactSetDetail));
}
function artifactSetOptions(selected=""){
  const sel=String(selected||"").trim().toLowerCase();
  const preferred=String(current?.lastArtifactSet||"").trim().toLowerCase();
  const chosen=artifactSets.find(x=>String(x.name||"").toLowerCase()===sel || String(x.englishName||"").toLowerCase()===sel);
  const suggested=artifactSets.find(x=>String(x.name||"").toLowerCase()===preferred || String(x.englishName||"").toLowerCase()===preferred);
  const firstSet=chosen||suggested;
  const used=new Set();
  const ordered=[];
  if(firstSet){ordered.push(firstSet);used.add(firstSet.name.toLowerCase());}
  for(const x of artifactSets){
    const k=String(x.name||"").toLowerCase();
    if(!used.has(k)){ordered.push(x);used.add(k);}
  }
  const first=chosen
    ? `<option value="${esc(chosen.name)}" selected>${esc(chosen.name)}</option><option value="">Aucun set</option>`
    : `<option value="" selected>Aucun set</option>${suggested?`<option value="${esc(suggested.name)}">${esc(suggested.name)}</option>`:''}`;
  const tail=ordered.filter(x=>!chosen || String(x.name||"").toLowerCase()!==String(chosen.name||"").toLowerCase()).filter(x=>!suggested || chosen || String(x.name||"").toLowerCase()!==String(suggested.name||"").toLowerCase());
  return first + tail.map(x=>`<option value="${esc(x.name)}">${esc(x.name)}</option>`).join("");
}
function artifactSetStatBonuses(text){
  const t=String(text||"").replace(/[’]/g,"'").replace(/\s+/g," ").trim();
  const out=[];
  const add=(stat,value)=>{value=Number(value);if(Number.isFinite(value)&&value!==0)out.push({stat,value});};
  const rules=[
    [/\b(?:increases?|increase|raises?|raise|grants?|gains?|gain|boosts?|boost)\s+(?:the\s+)?(?:character's\s+)?(?:maximum\s+)?hp\s+(?:by\s+)?(\d+(?:\.\d+)?)\s*%/ig,"PV%"],
    [/\b(?:maximum\s+)?hp\s+(?:is\s+)?(?:increased|raised|boosted)\s+(?:by\s+)?(\d+(?:\.\d+)?)\s*%/ig,"PV%"],
    [/\b(?:increases?|increase|raises?|raise|grants?|gains?|gain|boosts?|boost)\s+(?:the\s+)?(?:character's\s+)?atk\s+(?:by\s+)?(\d+(?:\.\d+)?)\s*%/ig,"ATQ%"],
    [/\batk\s+(?:is\s+)?(?:increased|raised|boosted)\s+(?:by\s+)?(\d+(?:\.\d+)?)\s*%/ig,"ATQ%"],
    [/\b(?:increases?|increase|raises?|raise|grants?|gains?|gain|boosts?|boost)\s+(?:the\s+)?(?:character's\s+)?def\s+(?:by\s+)?(\d+(?:\.\d+)?)\s*%/ig,"DEF%"],
    [/\bdef\s+(?:is\s+)?(?:increased|raised|boosted)\s+(?:by\s+)?(\d+(?:\.\d+)?)\s*%/ig,"DEF%"],
    [/\b(?:increases?|increase|raises?|raise|grants?|gains?|gain|boosts?|boost)\s+(?:the\s+)?(?:character's\s+)?(?:energy\s+recharge|recharge)\s+(?:by\s+)?(\d+(?:\.\d+)?)\s*%/ig,"Recharge d'énergie"],
    [/\b(?:energy\s+recharge|recharge)\s+(?:is\s+)?(?:increased|raised|boosted)\s+(?:by\s+)?(\d+(?:\.\d+)?)\s*%/ig,"Recharge d'énergie"],
    [/\b(?:increases?|increase|raises?|raise|grants?|gains?|gain|boosts?|boost)\s+(?:the\s+)?(?:character's\s+)?elemental\s+mastery\s+(?:by\s+)?(\d+(?:\.\d+)?)/ig,"Maîtrise élémentaire"],
    [/\belemental\s+mastery\s+(?:is\s+)?(?:increased|raised|boosted)\s+(?:by\s+)?(\d+(?:\.\d+)?)/ig,"Maîtrise élémentaire"],
    [/\b(?:increases?|increase|raises?|raise|grants?|gains?|gain|boosts?|boost)\s+(?:the\s+)?(?:character's\s+)?crit(?:ical)?\s+rate\s+(?:by\s+)?(\d+(?:\.\d+)?)\s*%/ig,"TC"],
    [/\bcrit(?:ical)?\s+rate\s+(?:is\s+)?(?:increased|raised|boosted)\s+(?:by\s+)?(\d+(?:\.\d+)?)\s*%/ig,"TC"],
    [/\b(?:increases?|increase|raises?|raise|grants?|gains?|gain|boosts?|boost)\s+(?:the\s+)?(?:character's\s+)?crit(?:ical)?\s+dmg\s+(?:by\s+)?(\d+(?:\.\d+)?)\s*%/ig,"DC"],
    [/\bcrit(?:ical)?\s+dmg\s+(?:is\s+)?(?:increased|raised|boosted)\s+(?:by\s+)?(\d+(?:\.\d+)?)\s*%/ig,"DC"],
    [/\b(?:increases?|increase|raises?|raise|grants?|gains?|gain|boosts?|boost)\s+(?:the\s+)?(?:character's\s+)?(?:healing\s+(?:bonus|effectiveness))\s+(?:by\s+)?(\d+(?:\.\d+)?)\s*%/ig,"Soin"],
    [/\b(?:healing\s+(?:bonus|effectiveness))\s+(?:is\s+)?(?:increased|raised|boosted)\s+(?:by\s+)?(\d+(?:\.\d+)?)\s*%/ig,"Soin"]
  ];
  const elem={pyro:"Bonus Pyro",hydro:"Bonus Hydro",electro:"Bonus Électro",cryo:"Bonus Cryo",anemo:"Bonus Anémo",geo:"Bonus Géo",dendro:"Bonus Dendro",physical:"Bonus physique"};
  const elemRules=[/(?:pyro|hydro|electro|cryo|anemo|geo|dendro|physical)\s+(?:elemental\s+)?(?:dmg|damage|bonus)\s+(?:is\s+)?(?:increased|raised|boosted)\s+(?:by\s+)?(\d+(?:\.\d+)?)\s*%/ig,/(?:increases?|increase|raises?|raise|grants?|gains?|gain|boosts?|boost)\s+(?:the\s+)?(?:pyro|hydro|electro|cryo|anemo|geo|dendro|physical)\s+(?:elemental\s+)?(?:dmg|damage|bonus)\s+(?:by\s+)?(\d+(?:\.\d+)?)\s*%/ig];
  for(const [re,stat] of rules){let m;while((m=re.exec(t)))add(stat,m[1]);}
  for(const re of elemRules){let m;while((m=re.exec(t))){const low=m[0].toLowerCase();for(const k in elem)if(low.includes(k)){add(elem[k],m[1]);break;}}}
  const flat=[[/\b(?:increases?|increase|raises?|raise|grants?|gains?|gain|boosts?|boost)\s+(?:the\s+)?(?:character's\s+)?(?:maximum\s+)?hp\s+(?:by\s+)?(\d+)\s*(?:points?|pts?)/ig,"PV flat"],[/\b(?:increases?|increase|raises?|raise|grants?|gains?|gain|boosts?|boost)\s+(?:the\s+)?(?:character's\s+)?(?:elemental\s+)?mastery\s+(?:by\s+)?(\d+)/ig,"Maîtrise élémentaire"]];
  for(const [re,stat] of flat){let m;while((m=re.exec(t)))add(stat,m[1]);}
  const fr=[[/augmente(?:nt)?\s+(?:les\s+)?(?:PV|points de vie)(?:\s+max(?:imum)?)?\s+de\s+(\d+(?:\.\d+)?)\s*%/ig,"PV%"],[/(?:les\s+)?(?:PV|points de vie)(?:\s+max(?:imum)?)?\s+(?:sont\s+)?augment[ée]s?\s+de\s+(\d+(?:\.\d+)?)\s*%/ig,"PV%"],[/augmente(?:nt)?\s+(?:l'|le\s+)?ATQ\s+de\s+(\d+(?:\.\d+)?)\s*%/ig,"ATQ%"],[/augmente(?:nt)?\s+(?:la\s+)?D[ÉE]F\s+de\s+(\d+(?:\.\d+)?)\s*%/ig,"DEF%"],[/augmente(?:nt)?\s+(?:la\s+)?ma[iî]trise [ée]l[ée]mentaire\s+de\s+(\d+(?:\.\d+)?)/ig,"Maîtrise élémentaire"],[/augmente(?:nt)?\s+(?:le\s+)?taux CRIT\s+de\s+(\d+(?:\.\d+)?)\s*%/ig,"TC"],[/augmente(?:nt)?\s+(?:les\s+)?D[ÉE]G[ÂA]TS CRIT\s+de\s+(\d+(?:\.\d+)?)\s*%/ig,"DC"],[/augmente(?:nt)?\s+(?:la\s+)?recharge d['’]?[ée]nergie\s+de\s+(\d+(?:\.\d+)?)\s*%/ig,"Recharge d'énergie"]];
  for(const [re,stat] of fr){let m;while((m=re.exec(t)))add(stat,m[1]);}
  const seen=new Set();return out.filter(x=>{const k=x.stat+":"+x.value;if(seen.has(k))return false;seen.add(k);return true;});
}
function effectIsConditional(text){return /\b(when|after|upon|if|while|below|above|for every|each time|each|trigger(?:ing)?|using|hits?|defeating|gains?|stacks?|affected|nearby|off-field|on-field|reaction|elemental skill|elemental burst|normal attack|charged attack|plunging attack)\b/i.test(String(text||""));}
function activeArtifactSetData(){
  const counts={};
  Object.values(current?.artifacts||{}).forEach(a=>{const set=String(a?.set||"").trim();if(set)counts[set]=(counts[set]||0)+1;});
  return Object.entries(counts).map(([name,count])=>{const rec=artifactSetMap.get(name.toLowerCase());return rec?{...rec,count}:null}).filter(Boolean);
}
function activeSetBonuses(){
  const auto=[];const conditional=[];
  for(const set of activeArtifactSetData()){
    if(set.count>=2){
      const stats=artifactSetStatBonuses(set.effect2Pc);
      stats.forEach(x=>auto.push({...x,source:`${set.name} · 2 pièces`}));
      // Les bonus 2 pièces qui ne sont pas des stats (ex. DGT ATQ normales)
      // restent visibles dans le panneau pour ne jamais être perdus.
      if(!stats.length && set.effect2Pc){
        conditional.push({source:`${set.name} · 2 pièces`,description:set.effect2Pc,stats:[],is2pc:true,damageOnly:true});
      }
    }
    if(set.count>=4){
      const stats=artifactSetStatBonuses(set.effect4Pc);
      const cond=effectIsConditional(set.effect4Pc);
      const source=`${set.name} · 4 pièces`;
      if(cond){
        conditional.push({source,description:set.effect4Pc,stats,is4pc:true});
      }else if(stats.length){
        stats.forEach(x=>auto.push({...x,source,description:set.effect4Pc,is4pc:true}));
      }else if(set.effect4Pc){
        conditional.push({source,description:set.effect4Pc,stats:[],is4pc:true,damageOnly:true});
      }
    }
  }
  return {auto,conditional};
}
function renderSetConditions(){
  const el=$("setConditions");if(!el)return;
  const {conditional}=activeSetBonuses();
  if(!conditional.length){el.innerHTML=`<div class="empty">Aucun bonus conditionnel ou effet 4 pièces à activer.</div>`;return;}
  el.innerHTML=conditional.map(b=>{
    const checked=current?.setProcs?.[b.source]!==false;
    const statText=(b.stats||[]).map(x=>`${x.stat} +${fmt(x.value,x.stat.includes('%')?'%':'')}`).join(' · ');
    const note=b.damageOnly?'Effet 4 pièces actif pour le futur calcul des dégâts.':(statText||'Effet conditionnel');
    return `<label class="setProc"><input type="checkbox" data-set-proc="${esc(b.source)}" ${checked?'checked':''}><span><strong>${esc(b.source)}</strong><small>${esc(b.description||'Bonus conditionnel')}</small><em>${esc(note)}</em></span></label>`;
  }).join('');
  el.querySelectorAll('input[data-set-proc]').forEach(ch=>ch.onchange=()=>{current.setProcs=current.setProcs||{};current.setProcs[ch.dataset.setProc]=ch.checked;updateTotals();saveBuild();});
}

// Libellé d'élévation déterministe pour tous les personnages connus.
// Genshin-DB renvoie `specialized` comme une valeur numérique dans les stats, pas
// comme le nom de la stat. Une valeur comme 0.288 peut donc être PV%, DC, etc.
// On ne tente plus de deviner : le nom du personnage donne le libellé exact.
const ASCENSION_STAT_MAP={
"Aino":"Maîtrise élémentaire","Albedo":"Bonus Géo","Alhaitham":"Bonus Dendro","Aloy":"Bonus Cryo","Alyosha":"Recharge d'énergie","Amber":"ATQ%","Arataki Itto":"TC","Arlecchino":"DC","Baizhu":"PV%","Barbara":"PV%","Beidou":"Bonus Électro","Bennett":"Recharge d'énergie","Candace":"PV%","Charlotte":"ATQ%","Chasca":"TC","Chevreuse":"PV%","Chiori":"TC","Chongyun":"ATQ%","Citlali":"Maîtrise élémentaire","Clorinde":"TC","Collei":"ATQ%","Columbina":"TC","Cyno":"DC","Dahlia":"PV%","Dehya":"PV%","Diluc":"TC","Diona":"Bonus Cryo","Dori":"PV%","Durin":"DC","Emilie":"DC","Escoffier":"TC","Eula":"DC","Faruzan":"ATQ%","Fischl":"ATQ%","Flins":"DC","Freminet":"ATQ%","Furina":"TC","Gaming":"ATQ%","Ganyu":"DC","Gorou":"Bonus Géo","Hu Tao":"DC","Iansan":"ATQ%","Ifa":"Maîtrise élémentaire","Illuga":"Maîtrise élémentaire","Ineffa":"TC","Jahoda":"Soin","Jean":"Soin","Kachina":"Bonus Géo","Kaedehara Kazuha":"Maîtrise élémentaire","Kaeya":"Recharge d'énergie","Kamisato Ayaka":"DC","Kamisato Ayato":"DC","Kaveh":"Maîtrise élémentaire","Keqing":"DC","Kinich":"DC","Kirara":"PV%","Klee":"Bonus Pyro","Kujou Sara":"ATQ%","Kuki Shinobu":"PV%","Lan Yan":"ATQ%","Lauma":"Maîtrise élémentaire","Layla":"PV%","Linnea":"TC","Lisa":"Maîtrise élémentaire","Lohen":"DC","Lynette":"Bonus Anémo","Lyney":"TC","Mavuika":"DC","Mika":"PV%","Mona":"Recharge d'énergie","Mualani":"TC","Nahida":"Maîtrise élémentaire","Navia":"DC","Nefer":"DC","Neuvillette":"DC","Nicole":"ATQ%","Nilou":"PV%","Ningguang":"Bonus Géo","Noelle":"DEF%","Odette":"DC","Ororon":"ATQ%","Prune":"ATQ%","Qiqi":"Soin","Raiden Shogun":"Recharge d'énergie","Razor":"Bonus physique","Rosaria":"ATQ%","Sandrone":"TC","Sangonomiya Kokomi":"Bonus Hydro","Sayu":"Maîtrise élémentaire","Sethos":"Maîtrise élémentaire","Shenhe":"ATQ%","Shikanoin Heizou":"Bonus Anémo","Sigewinne":"PV%","Skirk":"DC","Sucrose":"Bonus Anémo","Tartaglia":"Bonus Hydro","Thoma":"ATQ%","Tighnari":"Bonus Dendro","Traveler":"ATQ%","Aether":"ATQ%","Lumine":"ATQ%","Varesa":"TC","Varka":"DC","Venti":"Recharge d'énergie","Vesna":"TC","Vodyanitsa":"PV%","Wanderer":"TC","Wriothesley":"DC","Xiangling":"Maîtrise élémentaire","Xianyun":"ATQ%","Xiao":"TC","Xilonen":"DEF%","Xingqiu":"ATQ%","Xinyan":"ATQ%","Yae Miko":"TC","Yanfei":"Bonus Pyro","Yaoyao":"PV%","Yelan":"TC","Yoimiya":"TC","Yumemizuki Mizuki":"Maîtrise élémentaire","Yun Jin":"Recharge d'énergie","Zhongli":"Bonus Géo","Zibai":"DC"
};
function ascensionStatFor(name){
  const key=String(name||'').trim().toLowerCase();
  const hit=Object.entries(ASCENSION_STAT_MAP).find(([k])=>k.toLowerCase()===key);
  return hit?hit[1]:'';
}

const RECENT_CHARACTER_FALLBACKS={
  "Vesna":{name:"Vesna",element:"Anemo",rarity:5,weaponType:"Sword",stats:{specialized:"CRIT Rate",90:{hp:13262,attack:354,defense:730,specialized:24.2}}},
  "Vodyanitsa":{name:"Vodyanitsa",element:"Hydro",rarity:5,weaponType:"Catalyst",stats:{specialized:"HP",90:{hp:14818,attack:108,defense:484,specialized:28.8}}}
};
const RECENT_CHARACTER_META={
  "vesna":{name:"Vesna",ascStat:"TC",ascValue:24.2},
  "vodyanitsa":{name:"Vodyanitsa",ascStat:"PV%",ascValue:28.8}
};
function recentFallbackFor(name){return RECENT_CHARACTER_FALLBACKS[name]||Object.values(RECENT_CHARACTER_FALLBACKS).find(x=>String(x.name).toLowerCase()===String(name).toLowerCase())||null}
function recentMetaFor(name){return RECENT_CHARACTER_META[String(name||"").toLowerCase()]||null}

async function loadDB(){try{await ensureGDB("characters");const names=gdbNames("characters");const merged=[...names];Object.keys(RECENT_CHARACTER_FALLBACKS).forEach(name=>{if(!merged.some(x=>String(x).toLowerCase()===name.toLowerCase()))merged.push(name)});db=merged.map(name=>gdbSearch("characters",name)[0]||RECENT_CHARACTER_FALLBACKS[name]||{name}).sort((a,b)=>String(a.name).localeCompare(String(b.name),"fr"));$('dbStatus').textContent=`Base chargée : ${db.length} personnages.`;renderResults()}catch(e){const names=Object.keys(RECENT_CHARACTER_FALLBACKS);db=names.map(name=>RECENT_CHARACTER_FALLBACKS[name]);$('dbStatus').textContent="Base Genshin-DB partiellement chargée.";renderResults()}}
async function findCharacter(name){
  // API Genshin-DB en priorité pour obtenir les textes en français.
  try{
    const r=await fetch(`${API}/characters?query=${encodeURIComponent(name)}&matchNames=true&matchAltNames=true&matchAliases=true&queryLanguages=english,french&resultLanguage=french`,{cache:"no-store"});
    if(r.ok){const j=await r.json();const d=j.result||j.data||j;if(d)return Array.isArray(d)?d[0]:d;}
  }catch(e){}
  try{const g=await ensureGDB("characters");const data=gdbSearch("characters",name)[0];if(data)return data}catch(e){}
  return recentFallbackFor(name);
}
async function findStats(name,level=90){try{const g=await ensureGDB("characters");const data=gdbSearch("characters",name)[0];if(data?.stats&&typeof data.stats==="object"){return data.stats[String(level)]||data.stats[level]||data.stats} if(typeof data?.stat==="function"){return data.stat(level)} if(typeof data?.stats==="function"){return data.stats(level)}}catch(e){}try{const r=await fetch(`${API}/stats?folder=characters&query=${encodeURIComponent(name)}&level=${level}&queryLanguages=english&resultLanguage=english`);const j=await r.json();return j.result||j.data||j}catch(e){}const fb=recentFallbackFor(name);return fb?.stats?.[String(level)]||fb?.stats?.[level]||null}
async function findAscensionMeta(name){
  try{
    const r=await fetch(`${API}/stats?folder=characters&query=${encodeURIComponent(name)}&dumpResult=true&queryLanguages=english,french&resultLanguage=english`,{cache:"no-store"});
    if(r.ok){const j=await r.json();return j?.result?.result||j?.result||j?.data||j||null;}
  }catch(e){}
  return null;
}
function normalizeImageUrl(v){
  if(typeof v!=="string"||!v.trim())return "";
  const s=v.trim();
  if(/^https?:\/\//i.test(s))return s;
  const file=s.split("/").pop();
  if(/^UI_[A-Za-z0-9_]+\.(png|jpg|jpeg|webp)$/i.test(file))return `https://res.cloudinary.com/genshin/image/upload/sprites/${file}`;
  if(/^UI_[A-Za-z0-9_]+$/i.test(file))return `https://res.cloudinary.com/genshin/image/upload/sprites/${file}.png`;
  return "";
}
const ARTWORK_OVERRIDES={
  "Aether":[
    "https://upload-os-bbs.hoyolab.com/upload/2025/01/12/302574871/431497c10271a74707a47f487ce118a5_7894455566562173755.webp?x-oss-process=image%2Fresize%2Cs_1000%2Fauto-orient%2C0%2Finterlace%2C1%2Fformat%2Cwebp%2Fquality%2Cq_70",
    "https://genshinbuild.com/images/Icons/Traveler.png"
  ],
  "Albedo":["https://genshinbuild.com/images/Icons/Albedo.png"],
  "Alyosha":[
    "https://genshinbuild.com/images/Icons/Alyosha.png",
    "https://lblog.fp.guinfra.com/file/6a72f18d01835deec73cdd60pXs3abax03"
  ],
  "Amber":["https://genshinbuild.com/images/Icons/Amber.png"],
  "Vesna":["https://genshinbuild.com/images/Icons/Vesna.png","https://genshinbuild.com/images/Icons/Vesna_Card.png"],
  "Vodyanitsa":["https://genshinbuild.com/images/Icons/Vodyanitsa.png","https://genshinbuild.com/images/Icons/Vodyanitsa_Card.png"]
};
function characterImageKey(name){
  const raw=String(name||"").trim();
  const aliases={
    "Hu Tao":"Hutao","Kamisato Ayaka":"Ayaka","Kamisato Ayato":"Ayato",
    "Kaedehara Kazuha":"Kazuha","Raiden Shogun":"Shougun","Kujou Sara":"Sara",
    "Sangonomiya Kokomi":"Kokomi","Kuki Shinobu":"Shinobu","Shikanoin Heizou":"Heizo",
    "Yae Miko":"Yae","Yun Jin":"Yunjin","Xianyun":"Liuyun",
    "Traveler":"PlayerBoy","Aether":"PlayerBoy","Lumine":"PlayerGirl",
    "Alhaitham":"Alhatham","Arataki Itto":"Itto","Baizhu":"Baizhuer",
    "Amber":"Ambor","Qin":"Jean","Jean":"Qin"
  };
  return aliases[raw]||raw.normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^A-Za-z0-9]/g,"");
}
function characterGenshinBuildKey(name){
  const raw=String(name||"").trim();
  const aliases={
    "Aether":"Aether","Lumine":"Lumine","Traveler":"Aether",
    "Amber":"Amber","Arataki Itto":"Itto","Alhaitham":"Alhaitham",
    "Baizhu":"Baizhu","Hu Tao":"HuTao","Kamisato Ayaka":"Ayaka","Kamisato Ayato":"Ayato",
    "Kaedehara Kazuha":"Kazuha","Raiden Shogun":"RaidenShogun","Kujou Sara":"KujouSara",
    "Sangonomiya Kokomi":"Kokomi","Kuki Shinobu":"KukiShinobu","Shikanoin Heizou":"Heizou",
    "Yae Miko":"YaeMiko","Yun Jin":"YunJin","Xianyun":"Xianyun"
  };
  return aliases[raw]||raw.replace(/[^A-Za-z0-9]/g,"");
}
function characterApiSlug(name){
  const raw=String(name||"").trim();
  const aliases={
    "Aether":"traveler-anemo","Lumine":"traveler-anemo","Traveler":"traveler-anemo",
    "Alhaitham":"alhaitham","Arataki Itto":"arataki-itto","Baizhu":"baizhu",
    "Hu Tao":"hu-tao","Kamisato Ayaka":"kamisato-ayaka","Kamisato Ayato":"kamisato-ayato",
    "Kaedehara Kazuha":"kaedehara-kazuha","Raiden Shogun":"raiden-shogun","Kujou Sara":"kujousara",
    "Sangonomiya Kokomi":"sangonomiya-kokomi","Kuki Shinobu":"kuki-shinobu","Shikanoin Heizou":"shikanoin-heizou",
    "Yae Miko":"yae-miko","Yun Jin":"yun-jin","Xianyun":"xianyun",
    "Amber":"amber","Albedo":"albedo","Aloy":"aloy","Aino":"aino","Alyosha":"alyosha"
  };
  return aliases[raw]||raw.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"");
}
function characterImageCandidates(name,primary=""){
  const raw=String(name||"").trim();
  const key=characterImageKey(raw);
  const gbKey=characterGenshinBuildKey(raw);
  const slug=characterApiSlug(raw);
  const out=[];
  const add=u=>{if(u&&typeof u==='string'&&!out.includes(u))out.push(u)};

  // Known-good artwork URLs are first, so broken records from an upstream API
  // can never hide an otherwise valid portrait.
  (ARTWORK_OVERRIDES[raw]||[]).forEach(add);
  add(`https://genshinbuild.com/images/Icons/${gbKey}.png`);
  add(`https://genshinbuild.com/images/Icons/${gbKey}_Card.png`);
  add(`https://genshin.jmp.blue/characters/${slug}/icon`);
  add(`https://api.genshin.dev/characters/${slug}/icon-big`);
  add(`https://api.genshin.dev/characters/${slug}/icon`);

  add(`https://raw.githubusercontent.com/CMHopeSunshine/GenshinWikiMap/master/resources/avatar/UI_AvatarIcon_${key}.png`);
  add(`https://raw.githubusercontent.com/CMHopeSunshine/GenshinWikiMap/master/resources/avatar/UI_AvatarIcon_${key}_Card.png`);
  add(`https://raw.githubusercontent.com/CMHopeSunshine/GenshinWikiMap/master/resources/avatar/UI_AvatarIcon_${key}_Circle.png`);
  add(`https://res.cloudinary.com/genshin/image/upload/sprites/UI_AvatarIcon_${key}.png`);
  add(`https://res.cloudinary.com/genshin/image/upload/sprites/UI_AvatarIcon_${key}_Card.png`);
  add(`https://res.cloudinary.com/genshin/image/upload/sprites/UI_AvatarIcon_${key}_Circle.png`);
  add(`https://upload-os-bbs.mihoyo.com/game_record/genshin/character_icon/UI_AvatarIcon_${key}.png`);
  add(`https://enka.network/ui/UI_AvatarIcon_${key}.png`);
  add(`${GDB_CDN}/images/UI_AvatarIcon_${key}.png`);
  add(`${GDB_CDN}/images/UI_AvatarIcon_${key}_Card.png`);
  if(primary) add(primary);
  return out;
}
function characterImageFallback(name){return characterImageCandidates(name)[0]||"";}
function imageFor(c){
  const name=c?.name||"";
  const candidates=characterImageCandidates(name);
  // Prefer the explicit stable artwork source over arbitrary image fields from
  // the API. API records can contain stale or missing artwork URLs.
  return candidates[0]||"";
}
function artworkFallback(img){
  if(!img)return;
  const name=img.dataset.artName||img.alt||"";
  let list=[];
  try{list=JSON.parse(img.dataset.artCandidates||"[]")}catch(e){}
  if(!list.length)list=characterImageCandidates(name);
  let i=Number(img.dataset.artIndex||0);
  const current=img.currentSrc||img.src||"";
  const pos=list.findIndex(u=>u===current);
  if(pos>=0)i=pos+1;
  if(i<list.length){
    img.dataset.artIndex=String(i);
    img.onerror=()=>artworkFallback(img);
    img.src=list[i];
    return;
  }
  img.removeAttribute("src");
  img.style.display="none";
  img.closest(".charArt")?.classList.add("artMissing");
}
window.artworkFallback=artworkFallback;
function bindCharacterArtworkFallbacks(){
  document.querySelectorAll("[data-art-name]").forEach(img=>{
    const name=img.dataset.artName;
    const list=characterImageCandidates(name);
    img.dataset.artCandidates=JSON.stringify(list);
    img.dataset.artIndex="0";
    img.onerror=()=>artworkFallback(img);
    img.alt=name;
    img.removeAttribute("src");
    if(list[0])img.src=list[0];
  });
}
function displayElement(x){return x?({Pyro:"Pyro",Hydro:"Hydro",Anemo:"Anémo",Geo:"Géo",Electro:"Électro",Cryo:"Cryo",Dendro:"Dendro"}[x]||x):""}
function canonicalCharacterName(name){
  const raw=String(name||'').trim();
  const hit=db.find(c=>String(c?.name||'').trim().toLowerCase()===raw.toLowerCase());
  return hit?.name||raw;
}
function selectDBCharacter(name){
  const canonical=canonicalCharacterName(name);
  openCharacter({name:canonical,db:true,level:90});
}
function renderResults(){const q=$('search').value.trim().toLowerCase();const list=db.filter(c=>!q||String(c.name).toLowerCase().includes(q));$('results').innerHTML=list.map(c=>{const img=imageFor(c);return `<button class="char" data-name="${esc(c.name)}"><span class="charArt">${img?`<img alt="${esc(c.name)}" aria-label="${esc(c.name)}" decoding="async" referrerpolicy="no-referrer" data-art-name="${esc(c.name)}">`:``}</span><span class="charInfo"><strong>${esc(c.name)}</strong><small>${esc(displayElement(c.element)||"Genshin")} · ${c.rarity?c.rarity+"★":""}</small></span><span class="choose">Choisir</span></button>`}).join("")||`<div class="empty">Aucun personnage trouvé.</div>`;document.querySelectorAll('.char').forEach(b=>b.onclick=()=>selectDBCharacter(b.dataset.name));bindCharacterArtworkFallbacks()}
let charSearchTimer;
$('search').oninput=()=>{
  clearTimeout(charSearchTimer);
  const q=$('search').value.trim().toLowerCase();
  if(!q){renderResults();return;}
  charSearchTimer=setTimeout(async()=>{
    try{
      await ensureGDB("characters");
      const gMatches=gdbSearch("characters",q);
      const fallbackMatches=Object.values(RECENT_CHARACTER_FALLBACKS).filter(c=>String(c.name).toLowerCase().includes(q));
      const merged=[...gMatches];
      for(const c of fallbackMatches){if(!merged.some(x=>String(x?.name||"").toLowerCase()===String(c.name).toLowerCase()))merged.push(c);}
      const matches=merged.slice(0,50);
      if(matches.length){
        $('results').innerHTML=matches.map(c=>`<button class="char" data-name="${esc(c.name)}"><span class="charArt"><img alt="${esc(c.name)}" aria-label="${esc(c.name)}" decoding="async" referrerpolicy="no-referrer" data-art-name="${esc(c.name)}"></span><span class="charInfo"><strong>${esc(c.name)}</strong><small>${esc(displayElement(c.element)||"Genshin")} · ${c.rarity?c.rarity+"★":""}</small></span><span class="choose">Choisir</span></button>`).join("");
        document.querySelectorAll('.char').forEach(b=>b.onclick=()=>selectDBCharacter(b.dataset.name));
        bindCharacterArtworkFallbacks();
      }else{$('results').innerHTML=`<div class="empty">Aucun personnage trouvé pour « ${esc(q)} ».</div>`}
    }catch(e){
      const fallbackMatches=Object.values(RECENT_CHARACTER_FALLBACKS).filter(c=>String(c.name).toLowerCase().includes(q));
      if(fallbackMatches.length){
        $('results').innerHTML=fallbackMatches.map(c=>`<button class="char" data-name="${esc(c.name)}"><span class="charArt"><img alt="${esc(c.name)}" data-art-name="${esc(c.name)}"></span><span class="charInfo"><strong>${esc(c.name)}</strong><small>${esc(displayElement(c.element)||"Genshin")} · ${c.rarity?c.rarity+"★":""}</small></span><span class="choose">Choisir</span></button>`).join("");
        document.querySelectorAll('.char').forEach(b=>b.onclick=()=>selectDBCharacter(b.dataset.name));
        bindCharacterArtworkFallbacks();
      }else renderResults();
    }
  },180);
};
function extractSpecialName(data){
  const direct=[data?.ascensionStat,data?.ascension_stat,data?.ascensionStatName,data?.ascension_stat_name,data?.specializedStat,data?.specialized_stat,data?.special,data?.specialized,data?.stats?.ascensionStat,data?.stats?.ascension_stat,data?.stats?.specializedStat,data?.stats?.specializedStatName];
  const directHit=direct.find(v=>typeof v==='string'&&v.trim());
  if(directHit)return directHit;
  const wanted=/^(specialized|special|ascensionstat|ascensionstatname|ascensionstatvalue|specializedstat|specializedstatname|substat|substatname)$/i;
  const seen=new Set();
  function walk(v,depth=0){
    if(!v||typeof v!=='object'||depth>10||seen.has(v))return '';
    seen.add(v);
    for(const [k,val] of Object.entries(v)){
      const key=String(k).toLowerCase().replace(/[ _-]/g,'');
      if(wanted.test(key)&&typeof val==='string'&&val.trim())return val;
      if(val&&typeof val==='object'){const hit=walk(val,depth+1);if(hit)return hit;}
    }
    return '';
  }
  return walk(data)||'';
}
function inferAscStat(data){return mapSpecial(extractSpecialName(data));}
function mapSpecial(x){const t=String(x).toLowerCase();if(t.includes('crit rate')||t.includes('taux critique')||t.includes('taux crit'))return'TC';if(t.includes('crit dmg')||t.includes('dégâts critiques')||t.includes('dégâts crit'))return'DC';if(t.includes('hp')||t.includes('pv'))return'PV%';if(t.includes('atk')||t.includes('attaque'))return'ATQ%';if(t.includes('def')||t.includes('défense'))return'DEF%';if(t.includes('recharge'))return"Recharge d'énergie";if(t.includes('elemental mastery')||t.includes('maîtrise'))return'Maîtrise élémentaire';if(t.includes('pyro'))return'Bonus Pyro';if(t.includes('hydro'))return'Bonus Hydro';if(t.includes('electro')||t.includes('électro'))return'Bonus Électro';if(t.includes('cryo'))return'Bonus Cryo';if(t.includes('anemo')||t.includes('anémo'))return'Bonus Anémo';if(t.includes('geo')||t.includes('géo'))return'Bonus Géo';if(t.includes('dendro'))return'Bonus Dendro';if(t.includes('physical')||t.includes('physique'))return'Bonus physique';return''}
function normalizeAscValue(value){
  const n=Number(value)||0;
  return Math.abs(n)>0&&Math.abs(n)<1?n*100:n;
}
// Les données Genshin-DB donnent parfois le DC d'élévation sous forme de
// valeur totale (50% de base inclus). Dans Teyvat Lab, la valeur d'élévation
// est toujours la valeur AJOUTÉE, car les 50% de DC de base sont déjà dans
// baseTotals(). Ainsi 88.4% affiché par la DB devient +38.4% d'élévation,
// pour un total correct de 88.4%. Les personnages personnalisés conservent
// exactement la valeur saisie par l'utilisateur.
function ascensionBonusValue(stat,value,isDb=false){
  const n=normalizeAscValue(value);
  // Pour les personnages issus de la DB, la valeur DC peut être fournie comme
  // valeur finale (50% de base inclus). Teyvat Lab stocke uniquement le bonus
  // d'élévation ajouté aux 50% universels.
  if(isDb && stat==='DC' && n>50) return n-50;
  return n;
}
function normalizeCurrentAscension(){
  if(!current?.db || current.ascStat!=='DC') return;
  const n=normalizeAscValue(current.ascValue);
  if(n>50) current.ascValue=n-50;
}
async function openCharacter(c){
  $('home').classList.add('hidden');$('app').classList.remove('hidden');$('back').classList.remove('hidden');
  let data=c.data||await findCharacter(c.name);
  let stats=c.stats||await findStats(c.name,c.level||90);
  const s=stats?.[String(c.level||90)]||stats?.[`${c.level||90}`]||stats||{};
  const ascMeta=await findAscensionMeta(c.name);
  const recent=recentMetaFor(c.name);
  const ascStat=ascensionStatFor(c.name)||c.ascStat||inferAscStat(data)||inferAscStat(ascMeta)||mapSpecial(s.specialized??s.special??'')||recent?.ascStat||'';
  const rawAsc=c.ascValue??s.specialized??recent?.ascValue??0;
  const ascValue=ascensionBonusValue(ascStat,rawAsc,!!c.db);
  current={id:c.id||crypto.randomUUID(),name:c.name,db:!!c.db,level:c.level||90,data,stats:s,ascStat,ascValue,equipment:c.equipment||[],weapon:c.weapon||null,artifacts:c.artifacts||{},bonuses:c.bonuses||[],setProcs:c.setProcs||{},lastArtifactSet:c.lastArtifactSet||""};
  normalizeCurrentAscension();renderAll();showTab('character')
}
function renderAll(){renderHero();renderChar();renderEquipment();renderArtifacts();renderBonuses();renderSetConditions();renderGenshinCharacterData();updateTotals();renderSaved()}
function renderGenshinCharacterData(){
  const el=$('genshinCharacterData');
  if(!el)return;
  if(!current?.db||!current?.data){el.innerHTML=`<div class="empty">Aucune donnée Genshin-DB pour ce personnage.</div>`;return;}
  el.innerHTML=`<div class="dbCharacterSource"><span>GENSHIN-DB</span><small>Toutes les informations disponibles pour ${esc(current.name)}</small></div>${renderDBValue(current.data,'Personnage')}`;
}
function renderHero(){const img=imageFor(current.data);const candidates=characterImageCandidates(current.name,img);const asc=current.ascStat?`${current.ascStat}${current.ascValue?` + ${fmt(current.ascValue,'%')}`:''}`:'Aucune';$('charHero').innerHTML=`<div class="hero">${img?`<img alt="${esc(current.name)}" data-art-name="${esc(current.name)}" decoding="async" referrerpolicy="no-referrer">`:''}<div><h1>${esc(current.name)}</h1><p>Niveau ${current.level} · ${esc(displayElement(current.data?.element)||'Personnage personnalisé')}</p><small>Élévation : <b>${esc(asc)}</b></small></div></div>`;bindCharacterArtworkFallbacks()}
function renderChar(){const base=current.stats||{};const hp=base.hp??base.HP??base.health??0,atk=base.attack??base.atk??base.ATK??0,def=base.defense??base.def??base.DEF??0;const recent=recentMetaFor(current.name);const detectedAsc=ascensionStatFor(current.name)||current.ascStat||inferAscStat(current.data)||mapSpecial(base.specialized??base.special??'')||recent?.ascStat||'';if(detectedAsc)current.ascStat=detectedAsc;if(!current.ascValue&&recent?.ascValue)current.ascValue=recent.ascValue;$('charForm').innerHTML=`<div class="formgrid"><label>Niveau<input id="cLevel" type="number" min="1" max="90" value="${current.level}"></label><label>PV de base<input id="cHP" type="number" value="${hp}"></label><label>ATQ de base<input id="cATK" type="number" value="${atk}"></label><label>DEF de base<input id="cDEF" type="number" value="${def}"></label><label>Élévation<select id="cAsc"><option value="">Aucune</option>${statOpts(detectedAsc)}</select></label><label>Bonus d'élévation ajouté<input id="cAscVal" type="number" step="0.1" value="${current.ascValue}"></label></div><div class="saveActions"><button id="saveChar" type="button" class="primary">↻ Actualiser et enregistrer</button></div>`;const ascEl=$('cAsc');if(ascEl&&detectedAsc&&[...ascEl.options].some(o=>o.value===detectedAsc)){ascEl.value=detectedAsc;ascEl.options[ascEl.selectedIndex].selected=true;}
  $('saveChar').onclick=async()=>{
    current.level=+$('cLevel').value||90;
    if(current.db){
      const fresh=await findStats(current.name,current.level);
      const s=fresh?.[String(current.level)]||fresh?.[`${current.level}`]||fresh||{};
      current.stats=s;
      const recent=recentMetaFor(current.name);
      const ascMeta=await findAscensionMeta(current.name);
      current.ascStat=ascensionStatFor(current.name)||inferAscStat(current.data)||inferAscStat(ascMeta)||mapSpecial(s.specialized??s.special??'')||current.ascStat||recent?.ascStat||'';
      current.ascValue=ascensionBonusValue(current.ascStat,s.specialized??current.ascValue??recent?.ascValue??0,true);
    }else{
      current.ascStat=$('cAsc').value;
      current.ascValue=+$('cAscVal').value||0;
      current.stats={hp:+$('cHP').value||0,attack:+$('cATK').value||0,defense:+$('cDEF').value||0,...current.stats};
    }
    saveBuild();
    renderAll();
  }
}
function saveBuild(){const i=builds.findIndex(x=>x.id===current.id);if(i>=0)builds[i]=structuredClone(current);else builds.push(structuredClone(current));save();renderSaved();updateTotals()}
async function openSavedBuild(id){
  const b=builds.find(x=>x.id===id);if(!b)return;
  current=structuredClone(b);
  const dbMatch=db.find(x=>String(x.name).toLowerCase()===String(current.name).toLowerCase());
  if(dbMatch||current.db){
    current.db=true;
    current.data=await findCharacter(current.name)||current.data;
    current.stats=await findStats(current.name,current.level||90)||current.stats;
    const s=current.stats?.[String(current.level||90)]||current.stats?.[`${current.level||90}`]||current.stats||{};
    current.stats=s;
    current.ascStat=ascensionStatFor(current.name)||inferAscStat(current.data)||mapSpecial(s.specialized??s.special??'')||current.ascStat||'';
    current.ascValue=ascensionBonusValue(current.ascStat,s.specialized??current.ascValue??0,true);
    normalizeCurrentAscension();
    saveBuild();
  }
  $('home').classList.add('hidden');$('app').classList.remove('hidden');$('back').classList.remove('hidden');renderAll();showTab('character')
}
function renderSaved(){$('saved').innerHTML=builds.length?builds.map(b=>`<div class="savedItem"><span>${esc(b.name)}</span><button data-id="${b.id}">Ouvrir</button></div>`).join(''):`<div class="empty">Aucun build enregistré.</div>`;document.querySelectorAll('.savedItem button').forEach(b=>b.onclick=()=>openSavedBuild(b.dataset.id))}
function baseTotals(){const b=current.stats||{};return{HP:Number(b.hp??b.HP??b.health??0),ATK:Number(b.attack??b.atk??b.ATK??0),DEF:Number(b.defense??b.def??b.DEF??0),TC:5,DC:50,"Recharge d'énergie":100,'Maîtrise élémentaire':0,'Bonus Pyro':0,'Bonus Hydro':0,'Bonus Électro':0,'Bonus Cryo':0,'Bonus Anémo':0,'Bonus Géo':0,'Bonus Dendro':0,'Bonus physique':0,'Soin':0}}
function updateTotals(){
  if(!current)return;
  const t=baseTotals();
  const pct={HP:0,ATK:0,DEF:0};
  const add=(stat,v)=>{v=Number(v)||0;if(stat==='PV%')pct.HP+=v;else if(stat==='ATQ%')pct.ATK+=v;else if(stat==='DEF%')pct.DEF+=v;else addFlat(t,stat,v)};
  if(current.ascStat)add(current.ascStat,current.ascValue);
  Object.values(current.artifacts||{}).forEach(a=>{if(!a)return;add(a.main,MAIN_VALUES[a.main]||0);(a.subs||[]).forEach(s=>{add(s.stat,s.initial);(s.procs||[]).forEach(v=>add(s.stat,v))})});
  if(current.weapon){
    const ws=current.weapon.stats||{};
    add('ATQ flat',ws.attack??ws.atk??ws.ATK??0);
    add('PV flat',ws.hp??ws.HP??0);
    add('DEF flat',ws.defense??ws.def??ws.DEF??0);
    const wstat=current.weapon.statType||weaponSpecialStat(current.weapon.data,ws);
    if(wstat) add(wstat,weaponSpecialValue(ws));
    if(current.weapon.passiveActive!==false){
      const passiveCrit=parseWeaponPassiveCrit(current.weapon.data);
      if(passiveCrit.TC) add('TC',passiveCrit.TC);
      if(passiveCrit.DC) add('DC',passiveCrit.DC);
    }
  }
  (current.equipment||[]).forEach(b=>add(b.stat,b.value));
  (current.bonuses||[]).forEach(b=>add(b.stat,b.value));
  const setEffects=activeSetBonuses();
  setEffects.auto.forEach(b=>add(b.stat,b.value));
  setEffects.conditional.forEach(b=>{
    if(current.setProcs?.[b.source]!==false){
      (b.stats||[]).forEach(x=>add(x.stat,x.value));
    }
  });
  t.HP=(t.HP)*(1+pct.HP/100);t.ATK=(t.ATK)*(1+pct.ATK/100);t.DEF=(t.DEF)*(1+pct.DEF/100);
  const rows=[['PV',t.HP,''],['ATK',t.ATK,''],['DEF',t.DEF,''],['TC',t.TC,'%'],['DC',t.DC,'%'],["Recharge d'énergie",t["Recharge d'énergie"],'%'],['Maîtrise élémentaire',t['Maîtrise élémentaire'],''],['Bonus Pyro',t['Bonus Pyro'],'%'],['Bonus Hydro',t['Bonus Hydro'],'%'],['Bonus Électro',t['Bonus Électro'],'%'],['Bonus Cryo',t['Bonus Cryo'],'%'],['Bonus Anémo',t['Bonus Anémo'],'%'],['Bonus Géo',t['Bonus Géo'],'%'],['Bonus Dendro',t['Bonus Dendro'],'%'],['Bonus physique',t['Bonus physique'],'%'],['Soin',t.Soin,'%']];
  $('totals').innerHTML=rows.map(x=>`<div class="stat"><span>${x[0]}</span><b>${fmt(x[1],x[2])}</b></div>`).join('')
}
function addFlat(t,stat,v){if(stat==='PV flat')t.HP+=v;else if(stat==='ATQ flat')t.ATK+=v;else if(stat==='DEF flat')t.DEF+=v;else if(stat in t)t[stat]+=v}
function totalArtifactProcs(arts){return Object.values(arts||{}).reduce((n,a)=>n+(a?.subs||[]).reduce((m,s)=>m+(s.procs||[]).length,0),0)}
function artifactImageFor(slot,a){
  if(!a?.set)return '';
  const rec=artifactSetMap.get(String(a.set).toLowerCase());
  if(!rec)return '';
  const key={Fleur:'flower',Plume:'plume',Sablier:'sands',Coupe:'goblet',Couronne:'circlet'}[slot];
  if(!key)return '';
  return artifactImageValue(rec,key)||rec.images?.[key]||'';
}
function renderArtifacts(){const data=current.artifacts||{};$('artifacts').innerHTML=SLOTS.map(slot=>artifactHTML(slot,data[slot]||null)).join('');document.querySelectorAll('.artifact').forEach(bindArtifact);const rolls=totalArtifactProcs(data);$('rollCounter').textContent=`${rolls} / 5 améliorations`}
function artifactHTML(slot,a){if(!a){return `<div class="artifact emptyArtifact" data-slot="${slot}"><div class="artifactTitle"><strong>${slot}</strong><span class="notAdded">Pièce non équipée</span></div><button class="addPiece primary" type="button">+ Ajouter ${slot}</button></div>`}const main=a.main||MAIN[slot][0],subs=a.subs||[],fav=!!a.favorite,img=artifactImageFor(slot,a);return `<div class="artifact isEquipped${fav?' isFavorite':''}" data-slot="${slot}"><div class="artifactArtwork${img?'':' noArtwork'}">${img?`<img src="${esc(img)}" alt="Artwork ${esc(slot)}" loading="lazy" onerror="this.parentElement.classList.add('broken')">`:`<span aria-hidden="true">✦</span>`}</div><div class="artifactBody"><div class="artifactTitle"><strong>${slot}</strong><select class="main">${opts(MAIN[slot],main)}</select><button class="removePiece danger" type="button">Retirer</button></div><label class="setLabel">Set d'artefact<select class="artifactSet">${artifactSetOptions(a.set||"")}</select></label><div class="subList">${subs.map((s,i)=>subHTML(s,i,main,subs)).join('')}</div><div class="artifactActions"><button class="addSub">+ Substat <span>${subs.length}/4</span></button><div class="favoriteActions"><span class="favoriteStar" aria-hidden="true">★</span><button class="favoriteBtn${fav?' active':''}" type="button">${fav?'Favori':'Favoris'}</button></div></div></div></div>`}
function subHTML(s,i,main,subs){const allowed=Object.keys(ROLLS).filter(x=>x!==main&&!subs.some((z,j)=>j!==i&&z.stat===x));const stat=s.stat||allowed[0]||Object.keys(ROLLS)[0],rolls=ROLLS[stat]||[];return `<div class="sub" data-i="${i}"><div class="subrow"><select class="substat">${opts(allowed,stat)}</select><select class="initial">${opts(rolls.map(String),String(s.initial??rolls[0]))}</select><button class="x remove">×</button></div><div class="procLine">${(s.procs||[]).map((v,j)=>`<div class="proc"><span>${j+1}</span><select class="pv">${opts(rolls.map(String),String(v))}</select><button class="removeProc">×</button></div>`).join('')}</div><button class="addProc" ${totalArtifactProcs(current.artifacts)>=5?'disabled':''}>+ Proc <span>${(s.procs||[]).length} sur 5</span></button></div>`}
function bindArtifact(box){const slot=box.dataset.slot;const addPiece=box.querySelector('.addPiece');if(addPiece){addPiece.onclick=()=>{current.artifacts[slot]={main:MAIN[slot][0],subs:[],favorite:false,set:""};renderArtifacts();updateTotals();saveBuild();return}}const removePiece=box.querySelector('.removePiece');if(removePiece)removePiece.onclick=()=>{delete current.artifacts[slot];renderArtifacts();updateTotals();saveBuild()};const mainEl=box.querySelector('.main');if(mainEl)mainEl.onchange=()=>{const old=current.artifacts[slot]||{};current.artifacts[slot]={...old,main:mainEl.value,subs:old.subs||[],favorite:!!old.favorite,set:old.set||""};renderArtifacts();renderSetConditions();updateTotals();saveBuild()};const setEl=box.querySelector('.artifactSet');if(setEl)setEl.onchange=async()=>{current.artifacts[slot].set=setEl.value;current.lastArtifactSet=setEl.value||current.lastArtifactSet||"";await fetchArtifactSetDetail(setEl.value);renderArtifacts();renderSetConditions();updateTotals();saveBuild()};const favoriteBtn=box.querySelector('.favoriteBtn');if(favoriteBtn)favoriteBtn.onclick=()=>{const art=current.artifacts[slot];if(!art)return;art.favorite=!art.favorite;renderArtifacts();saveBuild()};const addSub=box.querySelector('.addSub');if(addSub)addSub.onclick=()=>{const subs=current.artifacts[slot]?.subs||[];if(subs.length>=4)return;const main=box.querySelector('.main').value,used=subs.map(s=>s.stat),stat=Object.keys(ROLLS).find(x=>x!==main&&!used.includes(x));if(!stat)return;current.artifacts[slot]={...current.artifacts[slot],main,subs:[...subs,{stat,initial:ROLLS[stat][0],procs:[]}]};renderArtifacts();updateTotals()};box.querySelectorAll('.remove').forEach(b=>b.onclick=()=>{const i=+b.closest('.sub').dataset.i;current.artifacts[slot].subs.splice(i,1);renderArtifacts();updateTotals()});box.querySelectorAll('.substat').forEach(sel=>sel.onchange=()=>{const i=+sel.closest('.sub').dataset.i,sub=current.artifacts[slot].subs[i];sub.stat=sel.value;sub.initial=ROLLS[sel.value][0];sub.procs=[];renderArtifacts();updateTotals()});box.querySelectorAll('.initial').forEach(sel=>sel.onchange=()=>{const i=+sel.closest('.sub').dataset.i;current.artifacts[slot].subs[i].initial=+sel.value;updateTotals()});box.querySelectorAll('.pv').forEach(sel=>sel.onchange=()=>{const i=+sel.closest('.sub').dataset.i,j=[...sel.closest('.sub').querySelectorAll('.pv')].indexOf(sel);current.artifacts[slot].subs[i].procs[j]=+sel.value;updateTotals()});box.querySelectorAll('.removeProc').forEach(b=>b.onclick=()=>{const row=b.closest('.sub'),i=+row.dataset.i,j=[...row.querySelectorAll('.removeProc')].indexOf(b);current.artifacts[slot].subs[i].procs.splice(j,1);renderArtifacts();updateTotals()});box.querySelectorAll('.addProc').forEach(b=>b.onclick=()=>{if(totalArtifactProcs(current.artifacts)>=5)return;const row=b.closest('.sub'),i=+row.dataset.i,sub=current.artifacts[slot].subs[i];sub.procs.push(ROLLS[sub.stat][0]);renderArtifacts();updateTotals()})}

function renderEquipment(){
  const weapon=current.weapon;
  const passiveActive=weapon?.passiveActive!==false;
  const weaponHtml=weapon?`<div class="equippedWeaponCard"><div><small>ARME ÉQUIPÉE · NIVEAU 90</small><strong>${esc(weapon.name)}</strong><span>ATQ ${esc(weapon.stats?.attack??weapon.stats?.atk??weapon.stats?.ATK??"—")} · ${esc(weaponSpecialLabel(weapon.data))} ${esc(weapon.stats?.specialized??"—")}</span></div><div class="weaponActions"><button class="weaponToggle ${passiveActive?'on':'off'}" type="button" aria-pressed="${passiveActive}">${passiveActive?'✓ Passif activé':'○ Passif désactivé'}</button><button class="danger removeWeapon" type="button">Retirer</button></div></div>`:`<div class="empty weaponEmpty">Aucune arme équipée. Sélectionne une arme Genshin-DB ci-dessous.</div>`;
  $('equipmentRows').innerHTML=weaponHtml;
  const rw=$('.removeWeapon');
  if(rw)rw.onclick=()=>{current.weapon=null;renderEquipment();updateTotals();saveBuild()};
  const wt=$('.weaponToggle');
  if(wt)wt.onclick=()=>{current.weapon.passiveActive=current.weapon.passiveActive===false;renderEquipment();updateTotals();saveBuild()};
}
$('saveEquipment').onclick=()=>saveBuild();
function renderBonuses(){$('bonuses').innerHTML=(current.bonuses||[]).map((b,i)=>`<div class="bonus" data-i="${i}"><select class="bst">${statOpts(b.stat)}</select><input class="bval" type="number" step="0.1" value="${b.value??0}"><button class="danger bx">×</button></div>`).join('')||`<div class="empty">Aucune stat bonus.</div>`;document.querySelectorAll('.bonus').forEach(r=>{r.querySelector('.bst').onchange=()=>{current.bonuses[+r.dataset.i].stat=r.querySelector('.bst').value;updateTotals()};r.querySelector('.bval').oninput=()=>{current.bonuses[+r.dataset.i].value=+r.querySelector('.bval').value||0;updateTotals()};r.querySelector('.bx').onclick=()=>{current.bonuses.splice(+r.dataset.i,1);renderBonuses();updateTotals()}})}
$('addBonus').onclick=()=>{current.bonuses.push({stat:'PV%',value:0});renderBonuses();updateTotals()};$('saveBonus').onclick=()=>saveBuild();
$('createManual').onclick=()=>{const c={id:crypto.randomUUID(),name:$('mName').value.trim()||'Personnage personnalisé',db:false,level:+$('mLevel').value||90,ascStat:$('mAsc').value,ascValue:+$('mAscVal').value||0,stats:{hp:+$('mHP').value||0,attack:+$('mATK').value||0,defense:+$('mDEF').value||0},equipment:[],weapon:null,artifacts:{},bonuses:[],setProcs:{}};current=c;saveBuild();$('home').classList.add('hidden');$('app').classList.remove('hidden');$('back').classList.remove('hidden');renderAll();showTab('character')};
$('back').onclick=()=>{$('app').classList.add('hidden');$('home').classList.remove('hidden');$('back').classList.add('hidden');current=null};document.querySelectorAll('.tabs button').forEach(b=>b.onclick=()=>showTab(b.dataset.tab));function showTab(t){document.querySelectorAll('.tabs button').forEach(b=>b.classList.toggle('active',b.dataset.tab===t));document.querySelectorAll('.tab').forEach(x=>x.classList.add('hidden'));$(t).classList.remove('hidden')}
$('mAsc').innerHTML=`<option value="">Aucune</option>${statOpts()}`;loadDB();loadArtifactSets();renderSaved();

/* =========================
   Genshin-DB explorer
   ========================= */
const DB_API="https://genshin-db-api.vercel.app/api/v5";
const DB_FOLDERS=[
  ["characters","Personnages"],["weapons","Armes"],["artifacts","Artefacts"],
  ["talents","Talents"],["constellations","Constellations"],["materials","Matériaux"],
  ["foods","Nourriture"],["crafts","Fabrication"],["domains","Domaines"],
  ["enemies","Ennemis"],["animals","Animaux"],["outfits","Tenues"],
  ["windgliders","Ailes"],["namecards","Cartes de profil"],["geographies","Géographies"],
  ["achievements","Succès"],["achievementgroups","Groupes de succès"],
  ["adventureranks","Rangs d'aventure"],["elements","Éléments"],["emojis","Emojis"],
  ["voiceovers","Voix"],["tcgactioncards","Cartes Action TCG"],["tcgcardbacks","Dos de cartes TCG"],
  ["tcgcardboxes","Étuis TCG"],["tcgcharactercards","Cartes Personnage TCG"],
  ["tcgdetailedrules","Règles détaillées TCG"],["tcgenemycards","Cartes Ennemi TCG"],
  ["tcgkeywords","Mots-clés TCG"],["tcglevelrewards","Récompenses TCG"],
  ["tcgstatuseffects","Effets de statut TCG"],["tcgsummons","Invocations TCG"]
];
let dbFolder="characters",dbNames=[],dbObjects=[],dbRequest=0;

function dbLabel(folder){return (DB_FOLDERS.find(x=>x[0]===folder)||[folder,folder])[1]}
function dbResult(j){
  if(j&&j.result!==undefined)return j.result;
  if(j&&j.data!==undefined)return j.data;
  return j;
}
async function dbFetch(folder,params=""){
  try{
    await ensureGDB(folder);
    const usp=new URLSearchParams(params);
    const q=usp.get("query")||"";
    if(q==="names")return gdbNames(folder);
    const results=gdbSearch(folder,q);
    if(results.length)return results.length===1?results[0]:results;
  }catch(e){}
  const r=await fetch(`${DB_API}/${folder}?${params}`);
  if(!r.ok)throw new Error(`HTTP ${r.status}`);
  return dbResult(await r.json());
}
function openDatabase(){
  $("home").classList.add("hidden");$("app").classList.add("hidden");$("database").classList.remove("hidden");
  $("back").classList.add("hidden");
  renderDBNav();selectDBFolder("characters");
}
function closeDatabase(){
  $("database").classList.add("hidden");$("home").classList.remove("hidden");
  $("dbDetail").classList.add("hidden");
}
$("openDatabase").onclick=openDatabase;
$("dbHome").onclick=closeDatabase;

function renderDBNav(){
  $("dbNav").innerHTML=DB_FOLDERS.map(([id,label])=>`<button class="dbNavBtn ${id===dbFolder?"active":""}" data-folder="${id}"><span>${esc(label)}</span><small>${esc(id)}</small></button>`).join("");
  document.querySelectorAll(".dbNavBtn").forEach(b=>b.onclick=()=>selectDBFolder(b.dataset.folder));
}
async function selectDBFolder(folder){
  dbFolder=folder;dbRequest++;const request=dbRequest;renderDBNav();
  $("dbDetail").classList.add("hidden");$("dbList").classList.remove("hidden");$("dbSearch").value="";$("dbMeta").textContent="Chargement…";
  $("dbList").innerHTML=`<div class="empty">Chargement de ${esc(dbLabel(folder))}…</div>`;
  try{await ensureGDB(folder);dbNames=gdbNames(folder);if(request!==dbRequest)return;$("dbMeta").textContent=`${dbNames.length} entrées · source : genshin-db · dossier « ${dbLabel(folder)} »`;renderDBList();}
  catch(e){$("dbMeta").textContent="Recherche distante active";renderDBList();}
}
let dbSearchTimer;
function renderDBList(){
  const q=$("dbSearch").value.trim();
  if(!q){const list=dbNames.slice(0,120);$("dbList").innerHTML=list.map(name=>`<button class="dbCard" data-name="${esc(name)}"><span class="dbIcon">${esc(name.slice(0,1).toUpperCase())}</span><span><strong>${esc(name)}</strong><small>${esc(dbLabel(dbFolder))}</small></span><b>Voir →</b></button>`).join("")||`<div class="empty">Aucune donnée.</div>`;bindDBCards();return;}
  clearTimeout(dbSearchTimer);$("dbList").innerHTML=`<div class="empty">Recherche de « ${esc(q)} »…</div>`;dbSearchTimer=setTimeout(async()=>{try{await ensureGDB(dbFolder);const matches=gdbSearch(dbFolder,q).slice(0,120);$("dbList").innerHTML=matches.map(x=>{const name=x?.name||String(x);return `<button class="dbCard" data-name="${esc(name)}"><span class="dbIcon">${esc(name.slice(0,1).toUpperCase())}</span><span><strong>${esc(name)}</strong><small>${esc(dbLabel(dbFolder))}</small></span><b>Voir →</b></button>`}).join("")||`<div class="empty">Aucun résultat pour « ${esc(q)} ».</div>`;bindDBCards();}catch(e){$("dbList").innerHTML=`<div class="empty">Recherche impossible.<br><small>${esc(e.message)}</small></div>`}},150);
}
function bindDBCards(){document.querySelectorAll(".dbCard").forEach(b=>b.onclick=()=>openDBEntry(dbFolder,b.dataset.name));}
$("dbSearch").oninput=renderDBList;
async function openDBEntry(folder,name){
  const req=++dbRequest;
  $("dbList").classList.add("hidden");$("dbDetail").classList.remove("hidden");
  $("dbDetail").innerHTML=`<div class="panel"><button class="small dbBackList">← ${esc(dbLabel(folder))}</button><div class="empty">Chargement de la fiche…</div></div>`;
  $("dbDetail").querySelector(".dbBackList").onclick=()=>{$("dbDetail").classList.add("hidden");$("dbList").classList.remove("hidden")};
  try{
    const data=await dbFetch(folder,`query=${encodeURIComponent(name)}&matchNames=true&matchAltNames=true&matchAliases=true&queryLanguages=french,english&resultLanguage=french`);
    if(req!==dbRequest)return;
    $("dbDetail").innerHTML=`<div class="panel dbDetailHead"><button class="small dbBackList">← ${esc(dbLabel(folder))}</button><div><small>${esc(folder)}</small><h2>${esc(name)}</h2><p>Tous les champs renvoyés par genshin-db sont affichés ci-dessous.</p></div></div><div class="dbRaw">${renderDBValue(data,"root")}</div>`;
    $("dbDetail").querySelector(".dbBackList").onclick=()=>{$("dbDetail").classList.add("hidden");$("dbList").classList.remove("hidden")};
  }catch(e){
    $("dbDetail").innerHTML=`<div class="panel"><button class="small dbBackList">← ${esc(dbLabel(folder))}</button><div class="empty">Fiche indisponible.<br><small>${esc(e.message)}</small></div></div>`;
    $("dbDetail").querySelector(".dbBackList").onclick=()=>{$("dbDetail").classList.add("hidden");$("dbList").classList.remove("hidden")};
  }
}
function renderDBValue(value,key){
  if(value===null||value===undefined)return `<div class="dbField"><span class="dbKey">${esc(key)}</span><span class="dbNull">null</span></div>`;
  if(typeof value==="string"){
    const safe=esc(value);
    if(/^https?:\/\/.+\.(png|jpg|jpeg|webp|gif)(\?.*)?$/i.test(value))
      return `<div class="dbField"><span class="dbKey">${esc(key)}</span><div><img class="dbImg" src="${safe}" loading="lazy" onerror="this.style.display='none'"><a href="${safe}" target="_blank" rel="noopener">Ouvrir l’image</a></div></div>`;
    if(/^https?:\/\//i.test(value))return `<div class="dbField"><span class="dbKey">${esc(key)}</span><a href="${safe}" target="_blank" rel="noopener">${safe}</a></div>`;
    return `<div class="dbField"><span class="dbKey">${esc(key)}</span><span class="dbVal">${safe.replace(/\n/g,"<br>")}</span></div>`;
  }
  if(typeof value==="number"||typeof value==="boolean")return `<div class="dbField"><span class="dbKey">${esc(key)}</span><span class="dbVal">${esc(String(value))}</span></div>`;
  if(Array.isArray(value)){
    return `<details class="dbGroup" open><summary>${esc(key)} <em>${value.length} élément${value.length>1?"s":""}</em></summary><div class="dbChildren">${value.map((v,i)=>renderDBValue(v,`[${i}]`)).join("")||"<span class='dbNull'>tableau vide</span>"}</div></details>`;
  }
  if(typeof value==="object"){
    const entries=Object.entries(value);
    return `<details class="dbGroup" ${key==="root"?"open":""}><summary>${esc(key)} <em>${entries.length} champ${entries.length>1?"s":""}</em></summary><div class="dbChildren">${entries.map(([k,v])=>renderDBValue(v,k)).join("")||"<span class='dbNull'>objet vide</span>"}</div></details>`;
  }
  return `<div class="dbField"><span class="dbKey">${esc(key)}</span><span class="dbVal">${esc(String(value))}</span></div>`;
}

/* =========================
   Genshin-DB sources de stats
   ========================= */
const MODIFIER_DB_FOLDERS=[
  ["weapons","Armes"],["artifacts","Artefacts"],["foods","Nourriture"],
  ["talents","Talents"],["constellations","Constellations"],["materials","Matériaux"],
  ["crafts","Fabrication"],["domains","Domaines"],["enemies","Ennemis"],["characters","Personnages"]
];
let modifierDbFolder="weapons",modifierDbNames=[],modifierDbRequest=0,modifierDbSearchRequest=0,modifierDbDetailRequest=0;
function modifierDbLabel(folder){return (MODIFIER_DB_FOLDERS.find(x=>x[0]===folder)||[folder,folder])[1]}
function extractNames(value){
  // L'API renvoie une liste pour "names", mais un OBJET pour une recherche
  // qui ne trouve qu'une entrée. L'ancienne version jetait ce second cas.
  if(value==null)return [];
  if(typeof value==="string")return [value];
  if(Array.isArray(value))return value.flatMap(extractNames).filter(Boolean);
  if(value.result!==undefined)return extractNames(value.result);
  if(value.data!==undefined)return extractNames(value.data);
  const name=value.name||value.id||value.key;
  return name?[String(name)]:[];
}
async function fetchModifierNames(folder,q=""){
  const params=q
    ? `query=${encodeURIComponent(q)}&matchNames=true&matchAltNames=true&matchAliases=true&queryLanguages=english,french&resultLanguage=french`
    : `query=names&matchCategories=true&verboseCategories=false&resultLanguage=french&queryLanguages=english,french`;
  // API d'abord : elle sait rechercher par nom/alias et évite de dépendre
  // du chargement de tous les scripts de données dans le navigateur.
  try{
    const r=await fetch(`${DB_API}/${folder}?${params}`,{cache:"no-store"});
    if(r.ok){
      const j=await r.json();
      const names=extractNames(j);
      if(names.length)return [...new Set(names)];
    }
  }catch(e){}
  // Fallback local Genshin-DB.
  const data=await dbFetch(folder,params);
  return [...new Set(extractNames(data))];
}
function initModifierDB(){
  // Cette section est désormais dédiée aux armes. Il n'y a plus de sélecteur
  // de catégories ici : la catégorie est fixe sur "weapons".
  modifierDbFolder="weapons";
  const input=$("modifierDbSearch");
  if(!input)return;
  if(!input.dataset.bound){
    input.dataset.bound="1";
    input.oninput=searchModifierDB;
  }
  if(input.dataset.loaded!=="1"){
    input.dataset.loaded="1";
    loadModifierDBFolder("weapons");
  }
}
let weaponMetaCache=new Map();
let weaponMetaRequest=0;
async function resolveCharacterWeaponType(){
  let wanted=characterWeaponType();
  if(wanted)return wanted;
  if(!current)return '';
  try{
    const r=await fetch(`${DB_API}/characters?query=${encodeURIComponent(current.name)}&matchNames=true&matchAltNames=true&matchAliases=true&queryLanguages=english,french&resultLanguage=french`,{cache:"no-store"});
    if(r.ok){
      const j=await r.json();
      const d=dbResult(j);
      const data=Array.isArray(d)?d[0]:d;
      if(data){current.data={...(current.data||{}),...data};wanted=characterWeaponType();}
    }
  }catch(e){}
  return wanted;
}
async function getWeaponMeta(name){
  if(weaponMetaCache.has(name))return weaponMetaCache.get(name);
  let data=null;
  try{await ensureGDB("weapons");data=gdbSearch("weapons",name)[0]||null}catch(e){}
  if(!data){
    try{
      const r=await fetch(`${DB_API}/weapons?query=${encodeURIComponent(name)}&matchNames=true&matchAltNames=true&matchAliases=true&queryLanguages=english,french&resultLanguage=french`,{cache:"no-store"});
      if(r.ok){const j=await r.json();const d=dbResult(j);data=Array.isArray(d)?d[0]:d;}
    }catch(e){}
  }
  if(data)weaponMetaCache.set(name,data);
  return data;
}
async function hydrateWeaponMeta(names){
  const req=++weaponMetaRequest;
  const queue=names.filter(n=>!weaponMetaCache.has(n));
  let i=0;
  const workers=Array.from({length:Math.min(6,queue.length)},async()=>{
    while(i<queue.length){const name=queue[i++];await getWeaponMeta(name);}
  });
  await Promise.all(workers);
  if(req!==weaponMetaRequest)return;
  renderModifierDBList(true);
}
async function loadModifierDBFolder(folder){
  modifierDbFolder=folder;modifierDbRequest++;const req=modifierDbRequest;
  const input=$("modifierDbSearch"); if(input) input.value="";
  const status=$("modifierDbStatus");
  if(status)status.textContent=`Chargement des ${modifierDbLabel(folder).toLowerCase()}…`;
  $("modifierDbList").innerHTML=`<div class="empty">Chargement des ${esc(modifierDbLabel(folder).toLowerCase())}…</div>`;
  $("modifierDbDetail").innerHTML=`<div class="empty">Recherche une entrée puis sélectionne-la pour afficher sa fiche complète.</div>`;
  try{
    if(folder==="weapons")await resolveCharacterWeaponType();
    modifierDbNames=await fetchModifierNames(folder);
    if(req!==modifierDbRequest)return;
    if(folder==="weapons"){
      if(status)status.textContent=`Filtrage des armes compatibles…`;
      await hydrateWeaponMeta(modifierDbNames);
      if(req!==modifierDbRequest)return;
    }
    if(status)status.textContent=`${modifierDbNames.length} entrées chargées · Genshin-DB`;
    renderModifierDBList(true);
  }catch(e){
    if(req!==modifierDbRequest)return;
    modifierDbNames=[];
    if(status)status.textContent="Genshin-DB indisponible pour le moment.";
    $("modifierDbList").innerHTML=`<div class="empty">Impossible de charger cette catégorie.<br><small>${esc(e.message)}</small></div>`;
  }
}
function renderModifierDBList(hydrated=false){
  const q=$("modifierDbSearch")?.value.trim().toLowerCase()||"";
  let list=modifierDbNames.filter(n=>String(n).toLowerCase().includes(q));
  if(modifierDbFolder==="weapons"){
    const wanted=characterWeaponType();
    if(!wanted){
      $("modifierDbList").innerHTML=`<div class="empty">Impossible d'identifier le type d'arme de ${esc(current?.name||"ce personnage")}.</div>`;
      return;
    }
    // Une arme sans métadonnées n'est pas affichée : cela évite de montrer
    // temporairement des armes incompatibles pendant le chargement.
    list=list.filter(n=>{const d=weaponMetaCache.get(n);return !!d && compatibleWeapon(d);});
  }
  const cards=list.map(name=>({name,data:weaponMetaCache.get(name)||null}));
  $("modifierDbList").innerHTML=cards.map(item=>{
    const name=item.name,art=modifierDbFolder==="weapons"?weaponArtwork(item.data):"";
    return `<button class="dbCard modifierDbCard" data-name="${esc(name)}">${art?`<img class="modifierDbArtwork" src="${esc(art)}" alt="${esc(name)}" loading="lazy" onerror="this.onerror=null;this.style.display='none';this.nextElementSibling.style.display='grid'">`:""}<span class="dbIcon" style="${art?'display:none':''}">${esc(name.slice(0,1).toUpperCase())}</span><span><strong>${esc(name)}</strong><small>${esc(modifierDbLabel(modifierDbFolder))}</small></span><b>Afficher →</b></button>`;
  }).join("")||`<div class="empty">Aucun résultat${q?` pour « ${esc(q)} »`:""}.</div>`;
  document.querySelectorAll(".modifierDbCard").forEach(b=>b.onclick=async()=>{
    const name=b.dataset.name;
    if(modifierDbFolder==="weapons")await selectAndEquipWeapon(name);
    else await openModifierDBEntry(modifierDbFolder,name,false);
  });
  // Les armes sont déjà hydratées avant le premier rendu afin que seules les
  // armes compatibles apparaissent dans la liste défilable.
}
function searchModifierDB(){
  const q=$("modifierDbSearch")?.value.trim()||"";
  clearTimeout(window.__modifierDbTimer);
  window.__modifierDbTimer=setTimeout(()=>{
    const status=$("modifierDbStatus");
    const filtered=modifierDbNames.filter(n=>String(n).toLowerCase().includes(q.toLowerCase()));
    if(status)status.textContent=`${filtered.length} arme${filtered.length>1?"s":""} compatible${filtered.length>1?"s":""} · Genshin-DB`;
    renderModifierDBList();
  },80);
}
async function openModifierDBEntry(folder,name,scroll=true){
  const req=++modifierDbDetailRequest;
  const detail=$("modifierDbDetail");
  detail.innerHTML=`<div class="empty">Chargement de la fiche ${esc(name)}…</div>`;
  try{
    await ensureGDB(folder);
    let data=null;
    try{data=gdbSearch(folder,name)[0]||null}catch(e){console.warn("Recherche locale Genshin-DB",e)}
    if(!data){
      const params=`query=${encodeURIComponent(name)}&matchNames=true&matchAltNames=true&matchAliases=true&queryLanguages=english,french&resultLanguage=french`;
      const r=await fetch(`${DB_API}/${folder}?${params}`,{cache:"no-store"});
      if(r.ok)data=dbResult(await r.json());
    }
    if(Array.isArray(data))data=data[0];
    if(req!==modifierDbDetailRequest)return;
    if(!data){
      detail.innerHTML=`<div class="empty">Aucune donnée trouvée pour « ${esc(name)} ».<br><small>Le dossier Genshin-DB est chargé, mais cette entrée n'a pas pu être récupérée.</small></div>`;
      return;
    }
    let statsHtml="";
    let equipHtml="";
    let weaponStats=null;
    if(folder==="weapons") {
      weaponStats=await getWeaponStats90(name);
      statsHtml=renderWeaponStats90(weaponStats,data);
      equipHtml=`<div class="dbEquipAction"><button class="primary equipWeaponBtn" type="button">${current?.weapon?.name===String(data.name||name)?"✓ Arme équipée — niveau 90":"Équiper cette arme · niveau 90"}</button><small>Un seul emplacement d’arme est disponible par personnage.</small></div>`;
    }
    if(req!==modifierDbDetailRequest)return;
    detail.innerHTML=`<div class="dbCharacterSource"><span>GENSHIN-DB</span><small>${esc(modifierDbLabel(folder))} · ${esc(data.name||name)}</small></div>${equipHtml}${statsHtml}${renderDBValue(data,esc(data.name||name))}`;
    if(folder==="weapons") {
      const btn=detail.querySelector('.equipWeaponBtn');
      if(btn)btn.onclick=()=>equipGDBWeapon(data,name,weaponStats);
    }
    if(scroll && folder!=="weapons") detail.scrollIntoView({behavior:"smooth",block:"start"});
  }catch(e){
    console.error("Genshin-DB detail",e);
    if(req!==modifierDbDetailRequest)return;
    detail.innerHTML=`<div class="empty">Fiche indisponible.<br><small>${esc(e.message||e)}</small></div>`;
  }
}
async function selectAndEquipWeapon(name){
  if(!current){alert("Sélectionne d'abord un personnage.");return false;}
  const detail=$("modifierDbDetail");
  const status=$("modifierDbStatus");
  if(status)status.textContent=`Chargement de ${name}…`;
  try{
    // Récupération en français depuis l'API Genshin-DB.
    const params=`query=${encodeURIComponent(name)}&matchNames=true&matchAltNames=true&matchAliases=true&queryLanguages=english,french&resultLanguage=french`;
    let data=null;
    const r=await fetch(`${DB_API}/weapons?${params}`,{cache:"no-store"});
    if(r.ok){const j=await r.json();data=dbResult(j);if(Array.isArray(data))data=data[0];}
    if(!data){await ensureGDB("weapons");data=gdbSearch("weapons",name)[0]||null;}
    if(!data)throw new Error("Arme introuvable dans Genshin-DB");
    if(!compatibleWeapon(data)) {
      const typeName={sword:'Épée à une main',claymore:'Épée à deux mains',polearm:'Lance',bow:'Arc',catalyst:'Catalyseur'}[weaponTypeOf(data)]||'ce type d’arme';
      throw new Error(`Cette arme est de type ${typeName} et n’est pas compatible avec ${current.name}.`);
    }
    const stats=await getWeaponStats90(data.name||name);
    const weaponName=String(data.name||name);
    current.weapon={name:weaponName,level:90,data:structuredClone(data),stats:stats?structuredClone(stats):null,statType:weaponStatTypeFromData(data,stats),passiveActive:true};
    current.equipment=[];
    saveBuild();
    renderAll();
    showTab("weapon");
    // Rester en haut de l'onglet Arme : aucune navigation vers le détail en bas.
    requestAnimationFrame(()=>{window.scrollTo({top:0,left:0,behavior:"instant"});document.documentElement.scrollTop=0;document.body.scrollTop=0;});
    if(status)status.textContent=`✓ ${weaponName} équipée · niveau 90`;
    if(detail){detail.innerHTML=`<div class="dbCharacterSource"><span>GENSHIN-DB</span><small>${esc(weaponName)} · arme équipée niveau 90</small></div>${renderWeaponStats90(stats,data)}${renderDBValue(data,esc(weaponName))}`;}
    return true;
  }catch(e){
    console.error("Équipement arme Genshin-DB",e);
    if(status)status.textContent="Impossible d'équiper cette arme.";
    if(detail)detail.innerHTML=`<div class="empty">Impossible d'équiper cette arme.<br><small>${esc(e.message||e)}</small></div>`;
    return false;
  }
}
async function getWeaponStats90(name){
  // Priorité aux statistiques locales Genshin-DB si elles sont disponibles.
  try{
    await ensureGDB("weapons");
    const fn=window.GenshinDb?.weapons;
    const data=fn?.(name,{matchNames:true,matchAltNames:true,matchAliases:true});
    const statFn=data?.stats;
    if(typeof statFn==="function"){
      const local=statFn(90);
      if(local)return local;
    }
  }catch(e){console.warn("Stats locales arme Genshin-DB",e)}
  // Fallback officiel Genshin-DB API.
  try{
    const r=await fetch(`${DB_API}/stats?folder=weapons&query=${encodeURIComponent(name)}&level=90&queryLanguages=english,french&resultLanguage=french`,{cache:"no-store"});
    if(!r.ok)return null;
    const raw=dbResult(await r.json());
    if(raw&&typeof raw==="object"&&!Array.isArray(raw)) return raw["90"]||raw[90]||raw["90+"]||raw;
  }catch(e){console.warn("Stats arme Genshin-DB",e)}
  return null;
}
function normalizeWeaponType(value){
  if(typeof value==='number'){return ({0:'sword',1:'claymore',2:'polearm',3:'bow',4:'catalyst'})[value]||'';}
  if(value&&typeof value==='object'){
    for(const k of ['name','key','type','id','value']){const n=normalizeWeaponType(value[k]);if(n)return n;}
    return '';
  }
  const t=String(value??'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');
  if(/catalyst|catalyseur|magic|weapon_catalyst|catalyst/.test(t))return 'catalyst';
  if(/bow|arc|weapon_bow/.test(t))return 'bow';
  if(/claymore|epee a deux mains|two-handed|greatsword|weapon_claymore/.test(t))return 'claymore';
  if(/polearm|lance|spear|weapon_pole/.test(t))return 'polearm';
  if(/sword|epee|one-handed|weapon_sword/.test(t))return 'sword';
  return '';
}
function characterWeaponType(){
  const d=current?.data||{};
  const vals=[d.weaponType,d.weapon_type,d.weapon,d.weaponTypeName,d.weaponCategory,d.weaponTypeId,d.type,d.stats?.weaponType,d.stats?.weapon_type,d.info?.weaponType];
  for(const v of vals){const n=normalizeWeaponType(v);if(n)return n;}
  return '';
}
function weaponTypeOf(data){
  const vals=[data?.weaponType,data?.weapon_type,data?.type,data?.weapon,data?.weaponTypeName,data?.typeKey,data?.type_key];
  for(const v of vals){const n=normalizeWeaponType(v);if(n)return n;}
  return '';
}
function compatibleWeapon(data){
  const wanted=characterWeaponType();
  if(!wanted)return false;
  const got=weaponTypeOf(data);
  return !!got && got===wanted;
}
function weaponArtwork(data){
  const candidates=[
    data?.images?.icon,data?.images?.namegacha,data?.images?.nameGacha,
    data?.images?.nameawakenicon,data?.images?.nameAwakenIcon,
    data?.images?.awakenicon,data?.images?.awakenIcon,
    data?.images?.wish,data?.images?.full,data?.images?.nameicon,data?.images?.nameIcon,
    data?.image,data?.icon,data?.nameicon,data?.nameIcon
  ];
  return candidates.find(v=>typeof v==='string'&&/^https?:\/\//i.test(v))||'';
}
function collectStrings(obj,out=[],depth=0){
  if(depth>5||obj==null)return out;
  if(typeof obj==='string'){out.push(obj);return out;}
  if(Array.isArray(obj)){for(const v of obj)collectStrings(v,out,depth+1);return out;}
  if(typeof obj==='object'){for(const [k,v] of Object.entries(obj)){if(/substat|specialized|secondary|stat/i.test(k)&&typeof v==='string')out.push(v);collectStrings(v,out,depth+1)}}
  return out;
}
function weaponStatTypeFromData(data,stats){
  const direct=[data?.substatText,data?.substat,data?.substatType,data?.specialized,data?.special,data?.secondary,data?.stats?.specialized,data?.stats?.special];
  const text=direct.filter(v=>typeof v==='string').concat(collectStrings(data).slice(0,80)).join(' | ');
  const mapped=mapWeaponStatText(text);
  if(mapped)return mapped;
  // Certaines versions de la donnée exposent un identifiant FIGHT_PROP_*.
  const all=JSON.stringify(data||{}).toLowerCase();
  return mapWeaponStatText(all)||'';
}
function mapWeaponStatText(text){
  const t=String(text||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');
  if(/critical_hurt|critical damage|crit dmg|crit damage|degats? crit|dgt crit|fight_prop_critical_hurt/.test(t))return 'DC';
  if(/critical_rate|crit rate|critique|taux crit|chance crit|fight_prop_critical/.test(t))return 'TC';
  if(/hp_percent|hp%|health percent|pv percent|pv%|fight_prop_hp_percent/.test(t))return 'PV%';
  if(/attack_percent|atk%|attack percentage|attaque percent|attaque %|fight_prop_attack_percent/.test(t))return 'ATQ%';
  if(/defense_percent|def%|defense percentage|defense %|defense percent|fight_prop_defense_percent/.test(t))return 'DEF%';
  if(/energy_recharge|recharge/.test(t))return "Recharge d'énergie";
  if(/elemental_mastery|elemental mastery|maitrise elementaire|fight_prop_elemental_mastery/.test(t))return 'Maîtrise élémentaire';
  if(/pyro/.test(t))return 'Bonus Pyro'; if(/hydro/.test(t))return 'Bonus Hydro'; if(/electro/.test(t))return 'Bonus Électro';
  if(/cryo/.test(t))return 'Bonus Cryo'; if(/anemo/.test(t))return 'Bonus Anémo'; if(/geo/.test(t))return 'Bonus Géo'; if(/dendro/.test(t))return 'Bonus Dendro'; if(/physical|physique/.test(t))return 'Bonus physique';
  return '';
}
function weaponSpecialLabel(data){
  const label=data?.substatText||data?.substat||data?.substatType||data?.specialized||data?.special||data?.secondary||data?.stats?.specialized||data?.stats?.special||"Stat. secondaire";
  const t=String(label);
  if(/critical_hurt|crit\s*(dmg|damage)|dégâts?\s*crit/i.test(t))return 'DGT CRIT';
  if(/critical|crit\s*(rate|chance)|taux\s*crit/i.test(t))return 'Taux CRIT';
  if(/hp_percent|hp%|pv%|health percent/i.test(t))return 'PV%';
  if(/attack_percent|atk%|attaque %/i.test(t))return 'ATQ%';
  if(/defense_percent|def%|défense %/i.test(t))return 'DEF%';
  if(/energy_recharge|recharge/i.test(t))return "Recharge d'énergie";
  if(/elemental_mastery|elemental mastery|maîtrise/i.test(t))return 'Maîtrise élémentaire';
  return t;
}
function weaponSpecialStat(data,stats){
  // Genshin-DB expose parfois le type sous forme d'enum (ex. FIGHT_PROP_CRITICAL_HURT)
  // et parfois sous forme de texte traduit. On couvre les deux formats.
  const candidates=[
    data?.substatText,data?.substat,data?.substatType,data?.specialized,data?.special,
    data?.secondary,data?.subValue,data?.subvalue,data?.stats?.specialized,data?.stats?.special,
    stats?.specializedType,stats?.substatType,stats?.substatText,stats?.substat
  ].filter(v=>v!==undefined&&v!==null);
  const text=candidates.map(String).join(' | ').toLowerCase();
  const robust=mapWeaponStatText(text)||weaponStatTypeFromData(data,stats);
  if(robust)return robust;
  if(/critical_hurt|critical dmg|crit dmg|crit damage|dégâts? crit/i.test(text))return 'DC';
  if(/critical|crit rate|critique|taux crit|chance crit/i.test(text))return 'TC';
  if(/hp_percent|hp%|health percent|pv percent|pv%|hp percentage/i.test(text))return 'PV%';
  if(/attack_percent|atk%|attack percentage|attaque percent|attaque %/i.test(text))return 'ATQ%';
  if(/defense_percent|def%|defense percentage|défense %/i.test(text))return 'DEF%';
  if(/energy_recharge|recharge/i.test(text))return "Recharge d'énergie";
  if(/elemental_mastery|elemental mastery|maîtrise élémentaire/i.test(text))return 'Maîtrise élémentaire';
  if(/pyro/i.test(text))return 'Bonus Pyro';
  if(/hydro/i.test(text))return 'Bonus Hydro';
  if(/electro|électro/i.test(text))return 'Bonus Électro';
  if(/cryo/i.test(text))return 'Bonus Cryo';
  if(/anemo|anémo/i.test(text))return 'Bonus Anémo';
  if(/geo|géo/i.test(text))return 'Bonus Géo';
  if(/dendro/i.test(text))return 'Bonus Dendro';
  if(/physical|physique/i.test(text))return 'Bonus physique';
  const mapped=mapSpecial(text);
  if(mapped)return mapped;
  return '';
}
function weaponSpecialValue(stats){
  const raw=stats?.specialized??stats?.special??stats?.subValue??stats?.subvalue??0;
  const n=Number(raw);
  if(!Number.isFinite(n))return 0;
  // Genshin-DB renvoie les stats en décimal : 0.662 = 66.2%.
  return Math.abs(n)>0 && Math.abs(n)<1 ? n*100 : n;
}
function parseWeaponPassiveCrit(data){
  const text=[data?.passive?.description,data?.passiveDescription,data?.passive?.desc,data?.description].filter(Boolean).join(' ');
  const out={TC:0,DC:0};
  const rateRe=/(?:taux|chance)\s*(?:de\s*)?crit(?:ique)?[^%]{0,60}?(?:augmente|augmenté|augmente de|increase(?:s|d)?|increases)[^%]{0,20}(\d+(?:[.,]\d+)?)\s*%/i;
  const dmgRe=/(?:dégâts?\s*crit(?:iques)?|crit(?:ical)?\s*(?:dmg|damage))[^%]{0,60}?(?:augmente|augmenté|augmente de|increase(?:s|d)?|increases)[^%]{0,20}(\d+(?:[.,]\d+)?)\s*%/i;
  const simpleRate=/(?:augmente|increase(?:s|d)?)[^%.]{0,80}(?:taux|chance)\s*(?:de\s*)?crit(?:ique)?[^%]{0,30}(\d+(?:[.,]\d+)?)\s*%/i;
  const simpleDmg=/(?:augmente|increase(?:s|d)?)[^%.]{0,80}(?:dégâts?\s*crit(?:iques)?|crit(?:ical)?\s*(?:dmg|damage))[^%]{0,30}(\d+(?:[.,]\d+)?)\s*%/i;
  const r=text.match(rateRe)||text.match(simpleRate);
  const d=text.match(dmgRe)||text.match(simpleDmg);
  if(r)out.TC=Number(r[1].replace(',','.'));
  if(d)out.DC=Number(d[1].replace(',','.'));
  return out;
}
function renderWeaponStats90(stats,data){
  if(!stats)return `<div class="modifierStats"><h3>Statistiques niveau 90</h3><div class="empty">Les statistiques niveau 90 de cette arme ne sont pas disponibles pour le moment.</div></div>`;
  const hp=stats.hp??stats.HP??0,atk=stats.attack??stats.atk??stats.ATK??0,def=stats.defense??stats.def??stats.DEF??0;
  let special=weaponSpecialValue(stats);
  const label=weaponSpecialLabel(data);
  return `<div class="modifierStats"><h3>Statistiques · niveau 90</h3><div class="weaponStatGrid"><div><span>PV</span><b>${esc(hp)}</b></div><div><span>ATQ</span><b>${esc(atk)}</b></div><div><span>DEF</span><b>${esc(def)}</b></div><div><span>${esc(label||"Stat. secondaire")}</span><b>${esc(special)}</b></div></div></div>`;
}
async function equipGDBWeapon(data,name,stats){
  if(!current){
    alert("Sélectionne d'abord un personnage.");
    return false;
  }
  const weaponName=String(data?.name||name);
  if(!compatibleWeapon(data)){
    const typeName={sword:'Épée à une main',claymore:'Épée à deux mains',polearm:'Lance',bow:'Arc',catalyst:'Catalyseur'}[weaponTypeOf(data)]||'ce type d’arme';
    const status=$("modifierDbStatus"); if(status)status.textContent=`Arme incompatible : ${typeName}.`;
    return false;
  }
  if(!stats)stats=await getWeaponStats90(name);
  current.weapon={name:weaponName,level:90,data:structuredClone(data),stats:stats?structuredClone(stats):null,statType:weaponStatTypeFromData(data,stats),passiveActive:true};
  // Un seul slot d'arme : remplacer l'ancienne arme.
  current.equipment=[];
  renderEquipment();
  updateTotals();
  saveBuild();
  const detail=$('modifierDbDetail');
  const btn=detail?.querySelector('.equipWeaponBtn');
  if(btn){btn.textContent="✓ Arme équipée — niveau 90";btn.classList.add('equipped');}
  const status=$("modifierDbStatus");
  if(status)status.textContent=`✓ ${weaponName} équipée · niveau 90`;
  showTab("weapon");
  requestAnimationFrame(()=>{window.scrollTo({top:0,left:0,behavior:"instant"});document.documentElement.scrollTop=0;document.body.scrollTop=0;});
  return true;
}
function renderModifierStats(folder,name){
  return folder==="weapons"?getWeaponStats90(name).then(stats=>`<div class="modifierStats"><h3>Statistiques · niveau 90</h3>${stats?"":"<div class=\"empty\">Statistiques indisponibles.</div>"}</div>`):Promise.resolve("");
}
const _renderAllOriginal=renderAll;
renderAll=function(){_renderAllOriginal();initModifierDB()};

// Initialisation indépendante de la sélection d'un personnage.
// La base Genshin-DB des modificateurs doit être utilisable dès l'ouverture de la page.
try { initModifierDB(); } catch (e) {
  console.error("Initialisation Genshin-DB modificateurs", e);
}
